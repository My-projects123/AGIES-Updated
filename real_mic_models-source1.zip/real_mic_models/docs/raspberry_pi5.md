# Raspberry Pi 5 diagnostic workflow (software only)

**STOP: do not treat this as a finished Raspberry Pi deployment.**

This document is a *checklist for later*. The two-channel pipeline has been tested on the development machine (imports, pytest, WAV split). It has **not** been certified on Pi 5 hardware in this update.

Use **Raspberry Pi OS 64-bit**. Do not assume USB vs AUX vs a microphone brand. Linux ALSA names are whatever the kernel prints.

**Hardware limitation:** both microphones should go through the **same multi-channel USB audio interface**. A USB microphone plus the Pi 3.5 mm / AUX input is **not** synchronized two-channel capture (two clocks).

## Exact commands (on the Pi, later)

```bash
arecord -l
python pi_alsa_test.py
python audio_device_test.py --no-capture
python audio_device_test.py --device <index>
python two_mic_test.py --seconds 2 --device <index>
python live_two_mic.py --seconds 6
```

Success for `two_mic_test.py`: `channels == 2`, printed `Channel 1 = SPEECH` / `Channel 2 = REFERENCE`, and RMS/peak for each.

---

Use **Raspberry Pi OS 64-bit** (Bookworm). Pi 1 cannot do this. This stage uses ONNX Runtime INT8 on the speech channel only.

## 1. Flash the OS

1. On a laptop install Raspberry Pi Imager.
2. Choose **Raspberry Pi OS (64-bit)**.
3. Write the card, insert it, boot the Pi 5.
4. Finish the first-run wizard (user name, Wi-Fi).

## 2. Connect internet and update

Open **Terminal** on the Pi (the black `>_` icon). Type:

```bash
sudo apt update
sudo apt full-upgrade -y
```

**Success:** it finishes without “Failed to fetch”.  
**Fail:** check Wi-Fi; retry.

## 3. Install system libraries Python needs

```bash
sudo apt install -y python3-venv python3-pip libportaudio2 libsndfile1
```

**Success:** no error. `libportaudio2` is required for `sounddevice`.

## 4. Copy the project onto the Pi

USB stick, `scp`, or git — whichever you already use. Example with a USB stick mounted at `/media/pi/USB`:

```bash
cp -r /media/pi/USB/real_mic_models ~/real_mic_models
cd ~/real_mic_models
```

**Success:** `ls serve.py` prints `serve.py`.

If you **trained on Windows**, also copy the `models/` folder. The Pi does not need to train if the ONNX files are already there.

```bash
ls models/real_mic.int8.onnx models/real_mic.onnx
```

Prefer **INT8**. If INT8 is missing, FP32 still runs (heavier).

## 5. Python virtual environment

```bash
cd ~/real_mic_models
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

**Success:** `(.venv)` in the prompt; pip finishes.  
**Fail (torch on Pi):** install the Pi wheel PyTorch documents for aarch64, or skip training on the Pi and **only** install:

```bash
pip install numpy scipy soundfile fastapi uvicorn onnxruntime sounddevice
```

Live cleaning needs `onnxruntime`, not necessarily `torch`.

## 6. Plug the USB audio interface

Both microphones → **same** USB interface → Pi USB port.  
Headphones → Pi headphone jack or the interface’s headphone out. **Not Bluetooth.**

## 7. Check ALSA devices

```bash
arecord -l
```

**Success:** you see a card with capture devices, often `USB Audio`.  
**Fail:** empty list → cable, powered hub, or `dmesg | tail` after replugging.

```bash
arecord -L
```

Look for a `hw:` or `plughw:` device with 2 channels.

## 8. Confirm two input channels

```bash
source ~/real_mic_models/.venv/bin/activate
cd ~/real_mic_models
python audio_device_test.py --no-capture
```

**Success:** `TWO-CHANNEL INPUT: YES`  
**Fail:** see [troubleshooting](troubleshooting.md).

```bash
python audio_device_test.py
python record_test.py
```

## 9. Run TinyML live processing

```bash
python live_two_mic.py --seconds 8
```

**Success:** prints `TinyML loaded: True` (if ONNX is present) and writes `recordings/live_speech_clean.wav`.  
**Fail `TinyML loaded: False`:** copy `models/real_mic.int8.onnx` onto the Pi.

Website on the Pi (optional, if you attached a screen):

```bash
python serve.py
```

Open `http://127.0.0.1:8090` in Chromium. From another computer on the LAN use `http://<pi-ip>:8090` — the **microphone** may be blocked unless you use HTTPS or Chromium on the Pi itself. For capture, prefer `python live_two_mic.py` on the Pi.

## 10. Measure latency

The live page and `live_two_mic.py` print `latency_ms` **per hop** (software).  
Wired headphones only. Bluetooth is a future stage and would add tens of milliseconds.

A hop is 256 samples at 16 kHz = **16 ms** of audio plus compute. On Pi 5, hop compute should stay well under 16 ms for this 13k-parameter net. If it does not, use INT8, close the browser, and run `live_two_mic.py`.

## 11. Tests

```bash
python -m pytest
```

Hardware tests are not required for `pytest` (they skip capture).
