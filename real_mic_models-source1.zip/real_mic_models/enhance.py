"""Live hop processor: decision-directed Wiener × real-mic TinyML + speech gate.

This class cleans ONE channel (the speech microphone).
Two-microphone splitting lives in live_processor.TwoMicProcessor.

Blind path — no simulated battlefield overlay. No LMS / DCCRN in this file.
"""

from __future__ import annotations

import numpy as np

from config import HOP, N_FFT, SAMPLE_RATE, WIN_LENGTH
from infer import TinyInfer


class RealMicEnhancer:
    def __init__(self) -> None:
        self.win = np.hanning(WIN_LENGTH)
        bins = N_FFT // 2 + 1
        self.noise_psd = np.ones(bins) * 1e-6
        self.prev_gain = np.ones(bins)
        self.prev_pow = np.zeros(bins)
        self.acc = np.zeros(WIN_LENGTH)
        self.w2 = self.win ** 2
        self.buf = np.zeros(0)
        self.tiny = TinyInfer()
        self.gate = 1.0
        self.open = False
        self.hold = 0
        self.floor_db = -70.0
        self.levels: list[float] = []
        freqs = np.fft.rfftfreq(N_FFT, 1 / SAMPLE_RATE)
        self.speech_bins = (freqs >= 300) & (freqs <= 3400)

    def reset(self) -> None:
        self.__init__()

    def _wiener(self, frame: np.ndarray, ai_gain: np.ndarray | None) -> np.ndarray:
        spec = np.fft.rfft(frame * self.win, n=N_FFT)
        pow_y = np.abs(spec) ** 2
        phase = np.angle(spec)
        speechish = float(np.mean(pow_y[self.speech_bins]) / (np.mean(pow_y) + 1e-12))
        if speechish < 1.35:
            self.noise_psd = 0.97 * self.noise_psd + 0.03 * pow_y
        # decision-directed a priori SNR
        post = np.maximum(pow_y / (self.noise_psd + 1e-12) - 1.0, 0.0)
        priori = 0.92 * (self.prev_gain ** 2) * (self.prev_pow / (self.noise_psd + 1e-12)) + 0.08 * post
        g = priori / (priori + 1.0)
        g = np.clip(g, 0.05, 1.0)
        padded = np.concatenate([g[:1], g, g[-1:]])
        g = 0.25 * padded[:-2] + 0.5 * padded[1:-1] + 0.25 * padded[2:]
        if ai_gain is not None and len(ai_gain) == len(g):
            g = np.minimum(g, 0.35 * g + 0.65 * ai_gain)
        self.prev_gain = g
        self.prev_pow = pow_y
        rec = np.fft.irfft(np.sqrt(pow_y) * g * np.exp(1j * phase), n=N_FFT).real[:WIN_LENGTH]
        return rec * self.win

    def _gate_step(self, vad: float | None, hop: np.ndarray) -> float:
        conf = 0.0 if vad is None else float(vad)
        level_db = 20.0 * np.log10(float(np.sqrt(np.mean(hop ** 2))) + 1e-12)
        self.levels.append(level_db)
        if len(self.levels) > 156:
            self.levels.pop(0)
        self.floor_db = min(self.levels)
        conf *= float(np.clip((level_db - self.floor_db - 1.5) / 5.0, 0.0, 1.0))
        if self.open:
            if conf < 0.32:
                self.hold -= 1
                if self.hold <= 0:
                    self.open = False
            else:
                self.hold = 10
        elif conf >= 0.45:
            self.open = True
            self.hold = 10
        target = 1.0 if self.open else 10 ** (-32.0 / 20.0)
        rate = 0.5 if target > self.gate else 0.15
        self.gate += rate * (target - self.gate)
        return self.gate

    def process_block(self, pcm: np.ndarray) -> list[dict]:
        x = np.asarray(pcm, dtype=np.float64).reshape(-1)
        self.buf = np.concatenate([self.buf, x])
        hops = []
        while len(self.buf) >= WIN_LENGTH:
            frame = self.buf[:WIN_LENGTH]
            self.buf = self.buf[HOP:]
            ai_gain, vad = self.tiny.mask_frame(frame)
            rec = self._wiener(frame, ai_gain)
            self.acc = self.acc + rec
            denom = np.maximum(self.w2[:HOP], 0.42)
            hop = self.acc[:HOP] / denom
            self.acc = np.concatenate([self.acc[HOP:], np.zeros(HOP)])
            g = self._gate_step(vad, hop)
            hop = hop * g
            hops.append(
                {
                    "pcm": hop.astype(np.float32).tolist(),
                    "pcm_in": frame[:HOP].astype(np.float32).tolist(),
                    "tiny_vad": None if vad is None else float(vad),
                    "gate_open": bool(self.open),
                    "gate_db": float(20.0 * np.log10(self.gate + 1e-12)),
                    "ml": bool(self.tiny.ok),
                }
            )
        return hops

    def process_full(self, pcm: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Run a whole clip; return (raw_aligned, cleaned) at hop resolution."""
        hops = self.process_block(np.asarray(pcm, dtype=np.float32))
        if not hops:
            empty = np.zeros(0, dtype=np.float32)
            return empty, empty
        raw = np.concatenate([np.asarray(h["pcm_in"], dtype=np.float32) for h in hops])
        clean = np.concatenate([np.asarray(h["pcm"], dtype=np.float32) for h in hops])
        return raw, clean
