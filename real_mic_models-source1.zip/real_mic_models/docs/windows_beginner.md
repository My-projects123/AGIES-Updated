# Windows beginner guide

You will type commands in **Command Prompt** or **PowerShell**.  
Folder to use: the unzipped `real_mic_models` folder (the one that contains `serve.py`).

## 1. Install Python

1. Download Python **3.10 or 3.11** (64-bit) from https://www.python.org/downloads/windows/
2. Tick **Add python.exe to PATH**.
3. Open a **new** Command Prompt and type:

```bat
py -3 --version
```

**Success:** a line like `Python 3.11.x`  
**Fail:** `'py' is not recognized` → reinstall Python and tick PATH, then close and reopen the terminal.

## 2. Open the project folder

```bat
cd %USERPROFILE%\Desktop\real_mic_models
dir serve.py
```

**Success:** `serve.py` is listed.  
**Fail:** you are in the wrong folder. Use File Explorer, click the address bar, copy the path, then `cd` that path.

## 3. Create a virtual environment

```bat
py -3 -m venv .venv
```

**Success:** a new folder `.venv` appears.  
**Fail:** `No module named venv` → `py -3 -m pip install virtualenv` then retry.

## 4. Activate it

Command Prompt:

```bat
.venv\Scripts\activate
```

PowerShell (if you see “running scripts is disabled”):

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\.venv\Scripts\Activate.ps1
```

**Success:** the prompt starts with `(.venv)`.

## 5. Install requirements

```bat
python -m pip install --upgrade pip
pip install -r requirements.txt
```

**Success:** no red error at the end; `torch` and `onnxruntime` installed.  
**Fail (torch):** install CPU PyTorch then retry requirements:

```bat
pip install torch --index-url https://download.pytorch.org/whl/cpu
pip install -r requirements.txt
```

**Fail (sounddevice):** Windows usually has a wheel. If not, install [Visual C++ Redistributable](https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist).

Skip `pesq` unless you need a real PESQ number.

## 6. Connect the USB audio interface

Plug in **one** USB interface. Plug **both** microphones into **that same box**.  
Windows Settings → Privacy → Microphone → allow desktop apps.

## 7. Check the microphone device

```bat
python audio_device_test.py --no-capture
```

**Success:** a table of devices and `TWO-CHANNEL INPUT: YES`  
**Fail `NO`:** Windows is seeing a 1-channel device (often the laptop mic). In Windows Sound settings, set the USB interface as default input, unplug built-in if needed, run again.

Then (hardware present):

```bat
python audio_device_test.py
```

Speak into the speech mic. Channel 1 RMS should jump.

## 8. Test two channels to a WAV

```bat
python record_test.py
```

**Success:** `OK — recordings/test_2ch.wav is a real two-channel file.`  
Open the JSON: `file_channels` is 2.

## 9. Record data + train (website)

```bat
python serve.py
```

**Success:** `Real-mic TinyML (two-mic) → http://127.0.0.1:8090`  
Leave this window open. In Chrome/Edge open that URL (must be `127.0.0.1`, not a random LAN IP, or the mic may be blocked).

Follow STEP 1 … STEP 7 on the page.

## 10. Check generated ONNX files

After train, in File Explorer open `models\`:

- `real_mic.pt`
- `real_mic.onnx`
- `real_mic.int8.onnx` (if quantization worked)
- `real_mic.meta.json`

```bat
dir models
```

## 11. Live processing

On the website: STEP 7 → START LIVE MIC.  
Or without the website:

```bat
python live_two_mic.py --seconds 6
```

Listen to `recordings\live_speech_clean.wav`.

## 12. Automated tests

```bat
python -m pytest
```

**Success:** `passed` (some ONNX tests skip if you have not trained yet).
