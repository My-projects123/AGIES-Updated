#!/usr/bin/env python3
"""Record a short stereo clip and report SPEECH vs REFERENCE levels.

    python two_mic_test.py
    python two_mic_test.py --seconds 2 --device 2

Writes recordings/test_2ch.wav (16 kHz, 2 channels, PCM16).

Prints:
    Channel 1 = SPEECH
    Channel 2 = REFERENCE
    RMS and peak for each
    whether both channels contain signal

Does not assume a microphone brand. Pass --device after audio_device_test.py.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from audio_io import read_wav_2ch_16k, write_wav_stereo  # noqa: E402
from config import RECORDINGS_DIR, SAMPLE_RATE, ensure_data_dirs, save_channel_config  # noqa: E402


def _stats(x: np.ndarray) -> dict:
    x = np.asarray(x, dtype=np.float64).reshape(-1)
    rms = float(np.sqrt(np.mean(x ** 2)))
    peak = float(np.max(np.abs(x))) if x.size else 0.0
    has_signal = rms >= 1e-4
    return {"rms": round(rms, 6), "peak": round(peak, 6), "has_signal": has_signal}


def main() -> int:
    parser = argparse.ArgumentParser(description="Two-mic RMS/peak test")
    parser.add_argument("--seconds", type=float, default=2.0)
    parser.add_argument("--device", type=int, default=None, help="PortAudio device index from audio_device_test.py")
    args = parser.parse_args()
    ensure_data_dirs()
    if args.device is not None:
        from config import channel_config

        cfg = channel_config()
        save_channel_config(int(cfg["speech_channel"]), int(cfg["reference_channel"]), args.device)

    print("Channel 1 = SPEECH")
    print("Channel 2 = REFERENCE")
    print("TinyML is not used in this test. We only check that two channels were captured.")
    print()
    try:
        from capture import record_stereo_seconds
    except Exception as exc:  # noqa: BLE001
        print("FAILED to import capture:", exc)
        return 1
    try:
        clip = record_stereo_seconds(args.seconds, args.device)
    except Exception as exc:  # noqa: BLE001
        print("FAILED:", exc)
        print("Connect both microphones to the SAME multi-channel USB audio interface.")
        print("A USB mic plus the Pi 3.5 mm / AUX jack is NOT synchronized two-channel capture.")
        return 2

    out = RECORDINGS_DIR / "test_2ch.wav"
    write_wav_stereo(out, clip["speech"], clip["reference"], SAMPLE_RATE)
    data, sr = sf.read(str(out), always_2d=True)
    stereo = read_wav_2ch_16k(out)
    if data.shape[1] != 2:
        print("FAILED: WAV channels ==", data.shape[1], "(need 2)")
        return 3
    sp = _stats(stereo[:, 0])
    rf = _stats(stereo[:, 1])
    report = {
        "path": str(out),
        "channels": int(data.shape[1]),
        "sample_rate": int(sr),
        "duration_seconds": round(data.shape[0] / float(sr), 3),
        "channel_1_SPEECH": sp,
        "channel_2_REFERENCE": rf,
        "both_channels_have_signal": sp["has_signal"] and rf["has_signal"],
        "device": clip["device"]["name"],
        "device_index": clip["device"]["index"],
    }
    print(json.dumps(report, indent=2))
    print()
    print("channels == 2  OK")
    print("Channel 1 SPEECH     RMS={rms}  peak={peak}  signal={has_signal}".format(**sp))
    print("Channel 2 REFERENCE  RMS={rms}  peak={peak}  signal={has_signal}".format(**rf))
    if not sp["has_signal"]:
        print("SPEECH channel looks silent — talk into the speech mic or swap SPEECH_CHANNEL.")
    if not rf["has_signal"]:
        print("REFERENCE channel looks silent — check the second cable, or swap REFERENCE_CHANNEL.")
    if sp["has_signal"] and rf["has_signal"]:
        print("Both channels contain signal.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
