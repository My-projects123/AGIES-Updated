from __future__ import annotations

from pathlib import Path

from config import MODELS

FP32_ONNX = MODELS / "real_mic.onnx"
INT8_ONNX = MODELS / "real_mic.int8.onnx"
META_JSON = MODELS / "real_mic.meta.json"
WEIGHTS = MODELS / "real_mic.pt"
MANIFEST = MODELS / "dataset_manifest.json"
