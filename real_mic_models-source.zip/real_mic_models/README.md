# Real-mic TinyML

Train the AEGIS **TinyMaskNet** (32-band GRU + VAD → ONNX INT8) on **your microphone**, not on Klatt-synthesized talkers.

This is a separate project from `sih26052_poc`. That POC still uses simulated speech for the shipped weights. This one records **you**, records **your room**, mixes those real clips, and trains a new ONNX file.

## Honest labels

| What | Label |
|---|---|
| Speech WAVs in `data/speech/` | **REAL** mic |
| Noise WAVs in `data/noise/` | **REAL** mic |
| `data/mixed/` pairs | **MIXED** — real speech + real noise added in software at a known SNR |
| `data/pairs/{id}_raw.wav` + `_clean.wav` | **REAL** same-take raw mic and cleaned mic |
| Live meters / live audio | **REAL** processing of the live mic through Wiener × this ONNX |
| DRDO field recordings / analog ANC | **Not this project** |

Additive mixing is still a lab trick (you did not record talker+noise in one take with a clean reference). The upgrade versus the SIH POC is that **both sources came out of a real microphone**.

## Run

```bash
cd real_mic_models   # or ~/AEGIS-COM-real-mic
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python serve.py
```

Open **http://127.0.0.1:8090** (port 8090 so it does not fight the SIH dashboard on 8080).

1. **Record speech** — quiet room, you talking, 8+ clips of 4 s. Vary sentences; leave pauses.
2. **Record noise** — same mic, nobody talking (fan, window, street). 8+ clips.
3. **Build dataset** then **Train model** (CPU, about a minute).
4. **Record raw+clean** — 4 s clip or live take; stop writes `data/pairs/{id}_raw.wav` and `{id}_clean.wav`.
5. **Start live mic** — hear the cleaned path; stop saves that take into the pair dataset.

CLI instead of the buttons:

```bash
python mix_dataset.py
python train.py
```

Writes `models/real_mic.int8.onnx`.

## Use the weights in the SIH website

Copy into the POC so the live dashboard uses the real-mic net:

```bash
cp models/real_mic.int8.onnx ../sih26052_poc/ml/models/tiny_mask.int8.onnx
cp models/real_mic.onnx     ../sih26052_poc/ml/models/tiny_mask.onnx
cp models/real_mic.pt       ../sih26052_poc/ml/models/tiny_mask.pt
cp models/real_mic.meta.json ../sih26052_poc/ml/models/tiny_mask.meta.json
```

Architecture matches (`gain`, `vad`, `h_out`, 32 bands, hidden 48). Restart `python serve.py` in `sih26052_poc`.

## Minimum data

- At least **4 speech** and **4 noise** clips to mix; **8+ of each** is the useful floor.
- If you skip training, live mode still runs **Wiener DSP only** (no TinyML mask/VAD).
