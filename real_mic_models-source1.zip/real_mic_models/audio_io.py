"""Load and save 16 kHz WAV files.

Two different readers exist on purpose:

  read_wav_mono_16k   — one channel, for Path A training and TinyML input
  read_wav_stereo_16k — two channels, for Path B dual-mic recordings

NEVER average (np.mean) the two microphones together. That would destroy
the reference channel that a later LMS/adaptive stage needs.

If you only have a mono file and you call the stereo reader, it raises
a clear error instead of inventing a second channel.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

from config import SAMPLE_RATE, channel_config


def _resample_1d(x: np.ndarray, sr: int, target: int = SAMPLE_RATE) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64).reshape(-1)
    if sr == target:
        return x
    g = int(np.gcd(sr, target))
    return np.asarray(resample_poly(x, target // g, sr // g), dtype=np.float64)


def resample_to_16k(x: np.ndarray, sr: int) -> np.ndarray:
    """Resample 1-D or (N, C) audio to 16 kHz. Each channel is resampled alone
    with the same ratio so the channels stay aligned in time."""
    x = np.asarray(x, dtype=np.float64)
    if x.ndim == 1:
        return _resample_1d(x, sr)
    cols = [_resample_1d(x[:, c], sr) for c in range(x.shape[1])]
    n = min(len(c) for c in cols)
    return np.stack([c[:n] for c in cols], axis=1)


def read_wav_mono_16k(path: Path, prefer_speech_channel: bool = True) -> np.ndarray:
    """Return shape (samples,) at 16 kHz.

    If the file is already mono, that channel is used.
    If the file is stereo, we take the configured SPEECH channel — we do
    **not** average left and right.
    """
    x, sr = sf.read(str(path), always_2d=True)
    x = np.asarray(x, dtype=np.float64)
    if x.shape[1] == 1:
        mono = x[:, 0]
    else:
        cfg = channel_config()
        idx = int(cfg["speech_channel"] if prefer_speech_channel else cfg["reference_channel"])
        idx = min(idx, x.shape[1] - 1)
        mono = x[:, idx]
    y = resample_to_16k(mono, int(sr))
    return np.clip(y, -1.0, 1.0).astype(np.float32)


def read_wav_stereo_16k(path: Path, *, hardware_order: bool = False) -> np.ndarray:
    """Return shape (samples, 2) at 16 kHz.

    Column 0 is the speech microphone.
    Column 1 is the reference microphone.

    Project files (data/dual_mic/synchronized, recordings/test_2ch.wav) are
    stored in that order already. Leave hardware_order=False for those.

    Set hardware_order=True only for a raw dump still in USB cable order;
    then SPEECH_CHANNEL / REFERENCE_CHANNEL are applied.
    """
    x, sr = sf.read(str(path), always_2d=True)
    x = np.asarray(x, dtype=np.float64)
    if x.shape[1] < 2:
        raise ValueError(
            f"{path} has only {x.shape[1]} channel(s). "
            "A two-microphone recording needs 2 channels. "
            "Connect both microphones to the same multi-channel USB audio interface."
        )
    y = resample_to_16k(x, int(sr))
    if hardware_order:
        cfg = channel_config()
        speech_i = min(int(cfg["speech_channel"]), y.shape[1] - 1)
        ref_i = min(int(cfg["reference_channel"]), y.shape[1] - 1)
        out = np.stack([y[:, speech_i], y[:, ref_i]], axis=1)
    else:
        out = y[:, :2]
    return np.clip(out, -1.0, 1.0).astype(np.float32)


def split_pcm_2ch(pcm_2ch: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Split capture-order stereo using SPEECH_CHANNEL / REFERENCE_CHANNEL.

    pcm_2ch shape is (samples, 2) as the USB interface reports it.
    Never averages the two microphones.
    """
    x = np.asarray(pcm_2ch, dtype=np.float32)
    if x.ndim == 1:
        if x.size % 2 != 0:
            raise ValueError("Interleaved stereo length must be even.")
        x = x.reshape(-1, 2)
    if x.ndim != 2 or x.shape[1] < 2:
        raise ValueError("Need pcm_2ch with shape (samples, 2). Do not downmix.")
    cfg = channel_config()
    s_i = int(cfg["speech_channel"])
    r_i = int(cfg["reference_channel"])
    if s_i == r_i:
        raise ValueError("SPEECH_CHANNEL and REFERENCE_CHANNEL must differ.")
    s_i = min(s_i, x.shape[1] - 1)
    r_i = min(r_i, x.shape[1] - 1)
    return x[:, s_i].copy(), x[:, r_i].copy()


def split_channels(stereo: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Split canonical (N, 2) or interleaved (2N,) into (speech, reference).

    After read_wav_2ch_16k, column 0 is already speech and column 1 is
    already reference, so this does not remap again.
    """
    x = np.asarray(stereo, dtype=np.float32)
    if x.ndim == 1:
        if x.size % 2 != 0:
            raise ValueError("Interleaved stereo length must be even.")
        x = x.reshape(-1, 2)
    if x.ndim != 2 or x.shape[1] < 2:
        raise ValueError("Need two channels to split.")
    return x[:, 0].copy(), x[:, 1].copy()


def read_wav_2ch_16k(path: Path, *, hardware_order: bool = False) -> np.ndarray:
    """Alias required by the two-mic spec. Same as read_wav_stereo_16k.

    Returns (samples, 2) with column 0 = SPEECH, column 1 = REFERENCE
    for canonical project files.
    """
    return read_wav_stereo_16k(path, hardware_order=hardware_order)


def interleave(speech: np.ndarray, reference: np.ndarray) -> np.ndarray:
    n = min(len(speech), len(reference))
    out = np.empty(n * 2, dtype=np.float32)
    out[0::2] = np.asarray(speech[:n], dtype=np.float32)
    out[1::2] = np.asarray(reference[:n], dtype=np.float32)
    return out


def write_wav(path: Path, x: np.ndarray, sr: int = SAMPLE_RATE) -> None:
    """Write mono (N,) or multi-channel (N, C) PCM16 WAV."""
    path.parent.mkdir(parents=True, exist_ok=True)
    arr = np.clip(np.asarray(x, dtype=np.float64), -1.0, 1.0)
    sf.write(str(path), arr, sr, subtype="PCM_16")


def write_wav_stereo(path: Path, speech: np.ndarray, reference: np.ndarray, sr: int = SAMPLE_RATE) -> None:
    n = min(len(speech), len(reference))
    stereo = np.stack(
        [np.asarray(speech[:n], dtype=np.float64), np.asarray(reference[:n], dtype=np.float64)],
        axis=1,
    )
    write_wav(path, stereo, sr)


def list_wavs(folder: Path) -> list[Path]:
    if not folder.exists():
        return []
    return sorted(p for p in folder.iterdir() if p.suffix.lower() in {".wav", ".flac"})


# Back-compat alias used by mix_dataset.py / train.py (Path A, mono).
def read_wav(path: Path) -> np.ndarray:
    return read_wav_mono_16k(path)


def to_mono_16k(x: np.ndarray, sr: int) -> np.ndarray:
    """Intentional mono conversion.

    If x is stereo we take the configured SPEECH channel.
    We never do np.mean(..., axis=-1) — that would destroy the reference mic.
    """
    x = np.asarray(x, dtype=np.float64)
    if x.ndim > 1:
        cfg = channel_config()
        idx = min(int(cfg["speech_channel"]), x.shape[-1] - 1)
        x = x[..., idx]
    y = resample_to_16k(np.reshape(x, -1), sr)
    return np.clip(y, -1.0, 1.0).astype(np.float32)
