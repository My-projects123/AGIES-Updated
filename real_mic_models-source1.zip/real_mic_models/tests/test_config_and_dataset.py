"""Channel config, dual-mic metadata, dataset honesty labels."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest

from audio_io import write_wav
from config import SAMPLE_RATE, save_channel_config
from dual_record import save_synchronized
from mix_dataset import build_dataset


def test_channel_config_rejects_same_index(tmp_path, monkeypatch):
    monkeypatch.setattr("config.CHANNEL_CONFIG_PATH", tmp_path / "ch.json")
    with pytest.raises(ValueError):
        save_channel_config(0, 0)


def test_channel_config_roundtrip(tmp_path, monkeypatch):
    path = tmp_path / "ch.json"
    monkeypatch.setattr("config.CHANNEL_CONFIG_PATH", path)
    cfg = save_channel_config(1, 0)
    assert cfg["speech_channel"] == 1
    assert cfg["reference_channel"] == 0
    assert path.exists()


def test_save_synchronized_metadata(tmp_path, monkeypatch):
    monkeypatch.setattr("dual_record.DUAL_SYNC_DIR", tmp_path / "sync")
    monkeypatch.setattr("dual_record.DUAL_SPEECH_DIR", tmp_path / "sp")
    monkeypatch.setattr("dual_record.DUAL_REF_DIR", tmp_path / "rf")
    monkeypatch.setattr("dual_record.SPEECH_DIR", tmp_path / "speech")
    monkeypatch.setattr("dual_record.NOISE_DIR", tmp_path / "noise")
    monkeypatch.setattr("dual_record.INDEX", tmp_path / "index.json")
    monkeypatch.setattr("dual_record.MANIFESTS_DIR", tmp_path)
    speech = (0.1 * np.random.default_rng(0).standard_normal(SAMPLE_RATE)).astype(np.float32)
    ref = (0.05 * np.random.default_rng(1).standard_normal(SAMPLE_RATE)).astype(np.float32)
    meta = save_synchronized(speech, ref, kind="speech", device_label="unit-test-device")
    assert meta["channels"] == 2
    assert meta["sample_rate"] == SAMPLE_RATE
    assert meta["speech_channel"] == 0
    assert meta["reference_channel"] == 1
    assert (tmp_path / "sync" / meta["file"]).exists()
    assert "REAL" in meta["label"]


def test_mix_dataset_honesty(tmp_path, monkeypatch):
    sp = tmp_path / "speech"
    nz = tmp_path / "noise"
    mx = tmp_path / "mixed"
    sp.mkdir(); nz.mkdir(); mx.mkdir()
    rng = np.random.default_rng(0)
    write_wav(sp / "s.wav", rng.standard_normal(SAMPLE_RATE).astype(np.float32) * 0.1)
    write_wav(nz / "n.wav", rng.standard_normal(SAMPLE_RATE).astype(np.float32) * 0.1)
    monkeypatch.setattr("mix_dataset.SPEECH_DIR", sp)
    monkeypatch.setattr("mix_dataset.NOISE_DIR", nz)
    monkeypatch.setattr("mix_dataset.MIXED_DIR", mx)
    monkeypatch.setattr("mix_dataset.MANIFEST", tmp_path / "man.json")
    meta = build_dataset(n_clips=16, seed=0)
    assert meta["path"] == "A"
    assert "SOFTWARE ADDITIVE MIXING" in meta["source"]
    assert meta["clips"] == 16
