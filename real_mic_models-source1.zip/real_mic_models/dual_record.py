"""Path B: save synchronized two-microphone recordings + metadata JSON."""

from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np

from audio_io import list_wavs, write_wav, write_wav_stereo
from config import (
    DUAL_REF_DIR,
    DUAL_SPEECH_DIR,
    DUAL_SYNC_DIR,
    MANIFESTS_DIR,
    NOISE_DIR,
    SAMPLE_RATE,
    SPEECH_DIR,
    channel_config,
    ensure_data_dirs,
)

INDEX = MANIFESTS_DIR / "dual_mic_index.json"


def _load_index() -> list[dict]:
    if not INDEX.exists():
        return []
    return json.loads(INDEX.read_text())


def _save_index(rows: list[dict]) -> None:
    MANIFESTS_DIR.mkdir(parents=True, exist_ok=True)
    INDEX.write_text(json.dumps(rows, indent=2))


def list_dual() -> list[dict]:
    return _load_index()


def save_synchronized(
    speech: np.ndarray,
    reference: np.ndarray,
    *,
    kind: str = "speech",
    device_label: str | None = None,
    capture_sample_rate: int | None = None,
    extra: dict | None = None,
) -> dict:
    """Store one synchronized take.

    kind:
      speech  — talker is speaking (also copies CH speech into dual_mic/speech)
      noise   — nobody talking (also copies CH reference into dual_mic/reference)
      live    — live test take
    """
    ensure_data_dirs()
    speech = np.asarray(speech, dtype=np.float32).reshape(-1)
    reference = np.asarray(reference, dtype=np.float32).reshape(-1)
    n = min(len(speech), len(reference))
    if n < SAMPLE_RATE // 2:
        raise ValueError("clip too short to save (need ≥ 0.5 s)")
    speech, reference = speech[:n], reference[:n]
    cfg = channel_config()
    pid = f"dual_{int(time.time() * 1000)}"
    stereo_name = f"{pid}_stereo.wav"
    meta_name = f"{pid}.json"
    write_wav_stereo(DUAL_SYNC_DIR / stereo_name, speech, reference)
    write_wav(DUAL_SPEECH_DIR / f"{pid}_speech.wav", speech)
    write_wav(DUAL_REF_DIR / f"{pid}_reference.wav", reference)
    # Path A still trains from data/speech + data/noise. Copy the matching channel
    # so a two-mic take can also feed the controlled mix without averaging channels.
    if kind == "speech":
        write_wav(SPEECH_DIR / f"{pid}.wav", speech)
    elif kind == "noise":
        write_wav(NOISE_DIR / f"{pid}.wav", reference)
    meta = {
        "id": pid,
        "kind": kind,
        "file": stereo_name,
        "speech_wav": f"{pid}_speech.wav",
        "reference_wav": f"{pid}_reference.wav",
        "sample_rate": SAMPLE_RATE,
        "channels": 2,
        "speech_channel": 0,  # after remap: column 0 is always speech
        "reference_channel": 1,
        "capture_speech_channel": int(cfg["speech_channel"]),
        "capture_reference_channel": int(cfg["reference_channel"]),
        "duration_seconds": round(n / SAMPLE_RATE, 3),
        "samples": int(n),
        "timestamp": int(time.time()),
        "device_label": device_label,
        "capture_sample_rate": capture_sample_rate,
        "microphone_configuration": cfg,
        "label": "REAL synchronized two-microphone recording",
        "stereo_url": f"/dual/{stereo_name}",
    }
    if extra:
        meta.update(extra)
    (DUAL_SYNC_DIR / meta_name).write_text(json.dumps(meta, indent=2))
    rows = _load_index()
    rows.append(meta)
    _save_index(rows)
    return meta


def dual_counts() -> dict:
    return {
        "synchronized": len(list_wavs(DUAL_SYNC_DIR)),
        "dual_speech": len(list_wavs(DUAL_SPEECH_DIR)),
        "dual_reference": len(list_wavs(DUAL_REF_DIR)),
        "dual_list": list_dual()[-12:],
    }
