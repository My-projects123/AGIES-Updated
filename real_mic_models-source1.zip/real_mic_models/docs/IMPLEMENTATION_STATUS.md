# Implementation status — two-mic TinyML stage

**Raspberry Pi deployment is STOPPED.** Software two-channel capture is the current goal.

The archive `real_mic_models-source.zip` previously still had the old reader:

```
if x.ndim > 1:
    x = np.mean(x, axis=-1)
```

That averaging is **gone** from `audio_io.py`. The zip is rebuilt from this folder.

## How the two channels are handled

```
pcm_2ch.shape == (samples, 2)     # USB / hardware order
speech    = pcm_2ch[:, SPEECH_CHANNEL]       # default 0
reference = pcm_2ch[:, REFERENCE_CHANNEL]    # default 1
speech → Wiener × TinyMaskNet × gate → speech_clean
reference is returned unchanged (future LMS). Never averaged.
```

Canonical project WAVs (`data/dual_mic/synchronized`, `recordings/test_2ch.wav`) store column 0 = speech, column 1 = reference.

## Files changed / added this pass

- `audio_io.py` — `read_wav_2ch_16k`, `split_pcm_2ch`, no `np.mean` across mics
- `live_processor.py` — `process_pcm_2ch`
- `audio_device_test.py` — `--device` to select input explicitly
- `two_mic_test.py` — stereo WAV + RMS/peak
- `pi_alsa_test.py` — ALSA listing only; does not claim Pi hardware tested
- `frontend/index.html`, `app.js` — TEST TWO MICROPHONES / RECORD TWO-MIC CLIP; live send is hardware-order
- `docs/raspberry_pi5.md`, `two_mic_setup.md`, `README.md`
- `tests/test_audio_io.py`, `tests/test_model_and_live.py`

Preserved: Path A mix/train, TinyMaskNet, `sih26052_poc` simulated weights, no DCCRN/wireless/S2.

## Commands

Development machine:

```bash
python -m pytest
python -c "import api, audio_io, live_processor; print('ok', api.app.title)"
python audio_device_test.py --no-capture
python serve.py
```

Later on Raspberry Pi 5 (not certified yet):

```bash
arecord -l
python pi_alsa_test.py
python audio_device_test.py --device <index>
python two_mic_test.py --device <index>
python live_two_mic.py --seconds 6
```
