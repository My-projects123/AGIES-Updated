"""Build training pairs from REAL mic speech + REAL mic noise.

Each mixed clip is: your recorded voice + a loop of your recorded room/fan/street
noise at a known SNR. The clean track is the speech recording (quiet-room), so
the IRM target is honest for additive mixing.

Also writes noise-only clips so the VAD head sees negatives.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from audio_io import list_wavs, read_wav, write_wav
from augment import augment_pair, mix_at_snr
from config import MIX_SECONDS, MIXED_DIR, NOISE_DIR, NOISE_ONLY_EVERY, SAMPLE_RATE, SNR_DB, SPEECH_DIR
from paths import MANIFEST


def _loop(x: np.ndarray, n: int) -> np.ndarray:
    if len(x) >= n:
        start = int(np.random.randint(0, max(1, len(x) - n + 1)))
        return x[start : start + n]
    reps = int(np.ceil(n / max(len(x), 1)))
    return np.tile(x, reps)[:n]


def _mix_at_snr(clean: np.ndarray, noise: np.ndarray, snr_db: float) -> np.ndarray:
    return mix_at_snr(clean, noise, snr_db)


def speech_mask(clean: np.ndarray, floor: float = 0.02) -> np.ndarray:
    """Frame-free sample mask: 1 where the quiet-room recording is above a floor."""
    rms = float(np.sqrt(np.mean(clean ** 2)) + 1e-12)
    return (np.abs(clean) > floor * rms).astype(np.float32)


def build_dataset(n_clips: int = 240, seed: int = 0) -> dict:
    speech = [read_wav(p) for p in list_wavs(SPEECH_DIR)]
    noise = [read_wav(p) for p in list_wavs(NOISE_DIR)]
    if not speech:
        raise SystemExit("No speech WAVs in data/speech/. Record yourself talking in a quiet room first.")
    if not noise:
        raise SystemExit("No noise WAVs in data/noise/. Record the room with nobody talking first.")

    MIXED_DIR.mkdir(parents=True, exist_ok=True)
    for old in MIXED_DIR.glob("*.wav"):
        old.unlink()
    rng = np.random.default_rng(seed)
    n_need = int(MIX_SECONDS * SAMPLE_RATE)
    rows = []
    for i in range(n_clips):
        noise_only = i % NOISE_ONLY_EVERY == 0
        n = _loop(noise[int(rng.integers(0, len(noise)))], n_need)
        if noise_only:
            noisy = n * float(rng.uniform(0.2, 0.8)) / (np.max(np.abs(n)) + 1e-12)
            clean = np.zeros(n_need, dtype=np.float32)
            mask = np.zeros(n_need, dtype=np.float32)
            snr = None
        else:
            s = _loop(speech[int(rng.integers(0, len(speech)))], n_need)
            snr = float(rng.choice(SNR_DB))
            noisy = np.clip(_mix_at_snr(s, n, snr), -1.0, 1.0)
            clean = s.astype(np.float32)
            noisy, clean = augment_pair(clean, noisy, rng, seed=40 + i)
            mask = speech_mask(clean)
        stem = f"{i:04d}_{'noise' if noise_only else 'mix'}"
        write_wav(MIXED_DIR / f"{stem}_noisy.wav", noisy)
        write_wav(MIXED_DIR / f"{stem}_clean.wav", clean)
        np.save(MIXED_DIR / f"{stem}_mask.npy", mask)
        rows.append({"id": stem, "noise_only": noise_only, "snr_db": snr})

    meta = {
        "clips": len(rows),
        "speech_files": len(speech),
        "noise_files": len(noise),
        "augmentation": [
            "random SNR -5..15 dB",
            "shared reverb RT60 0.12-0.40 s (35%)",
            "input clipping 0.55-0.95 (20%)",
            "random level 0.25-1.0",
            "mild extra pink on input (25%)",
        ],
        "source": "PATH A — REAL microphone recordings + SOFTWARE ADDITIVE MIXING (not a simultaneous two-mic field recording)",
        "path": "A",
        "tiny_ml_input": "speech_channel_only",
        "rows": rows,
    }
    MANIFEST.parent.mkdir(parents=True, exist_ok=True)
    MANIFEST.write_text(json.dumps(meta, indent=2))
    return meta


if __name__ == "__main__":
    m = build_dataset()
    print(f"wrote {m['clips']} mixed clips from {m['speech_files']} speech + {m['noise_files']} noise files")
