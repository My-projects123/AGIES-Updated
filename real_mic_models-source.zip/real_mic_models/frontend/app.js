const $ = (id) => document.getElementById(id);
const SR = 16000;
let clipSeconds = 4;
let recState = { running: false, ws: null, play: null };

async function refresh() {
  const st = await (await fetch("/api/status")).json();
  clipSeconds = st.clip_seconds || 4;
  $("nSpeech").textContent = st.speech;
  $("nNoise").textContent = st.noise;
  $("nMixed").textContent = st.mixed;
  $("nPairs").textContent = st.pairs || 0;
  $("nModel").textContent = st.trained ? "ONNX ready" : "not trained";
  const inf = st.infer || {};
  $("mlLine").textContent = inf.available
    ? `ONNX ${inf.quantized ? "INT8" : "FP32"} · ${inf.params || "?"} params · VAD acc ${inf.vad_accuracy ?? "—"} · ${inf.train_data}`
    : "ONNX: not trained yet — record, mix, train.";
  if (st.log) $("trainLog").textContent = st.log;
  renderPairs(st.pair_list || []);
  return st;
}

function renderPairs(rows) {
  const box = $("pairList");
  if (!rows.length) {
    box.innerHTML = '<p class="hint">No pairs yet. Record a clip or stop a live take.</p>';
    return;
  }
  box.innerHTML = rows.slice().reverse().map((p) => `
    <div class="pair-row">
      <div>
        <p class="lbl">${p.id}</p>
        <p class="hint">${p.seconds}s · ${p.source}</p>
      </div>
      <div>
        <p class="lbl">Raw mic</p>
        <audio controls src="${p.raw_url}"></audio>
      </div>
      <div>
        <p class="lbl">Cleaned mic</p>
        <audio controls src="${p.clean_url}"></audio>
      </div>
    </div>`).join("");
}

function resampleLinear(input, fromRate, toRate) {
  if (fromRate === toRate) return input;
  const ratio = fromRate / toRate;
  const n = Math.max(1, Math.floor(input.length / ratio));
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const x = i * ratio;
    const i0 = Math.floor(x);
    const f = x - i0;
    out[i] = (input[i0] || 0) * (1 - f) + (input[i0 + 1] || input[i0] || 0) * f;
  }
  return out;
}

async function captureSeconds(seconds, statusEl) {
  statusEl.textContent = "allow mic…";
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: { echoCancellation: true, noiseSuppression: false, autoGainControl: false },
  });
  const ctx = new AudioContext();
  const capRate = ctx.sampleRate;
  const src = ctx.createMediaStreamSource(stream);
  const node = ctx.createScriptProcessor(4096, 1, 1);
  const chunks = [];
  const need = Math.ceil(capRate * seconds);
  let n = 0;
  await new Promise((resolve) => {
    node.onaudioprocess = (ev) => {
      const pcm = ev.inputBuffer.getChannelData(0);
      chunks.push(new Float32Array(pcm));
      n += pcm.length;
      statusEl.textContent = `recording… ${(n / capRate).toFixed(1)}s`;
      if (n >= need) {
        node.disconnect();
        src.disconnect();
        stream.getTracks().forEach((t) => t.stop());
        ctx.close();
        resolve();
      }
    };
    const mute = ctx.createGain();
    mute.gain.value = 0;
    src.connect(node);
    node.connect(mute);
    mute.connect(ctx.destination);
  });
  const joined = new Float32Array(n);
  let o = 0;
  for (const c of chunks) {
    joined.set(c, o);
    o += c.length;
  }
  return Array.from(resampleLinear(joined.subarray(0, need), capRate, SR));
}

async function recordKind(kind) {
  const el = kind === "speech" ? $("speechStat") : $("noiseStat");
  const btn = kind === "speech" ? $("btnSpeech") : $("btnNoise");
  btn.disabled = true;
  try {
    const pcm = await captureSeconds(clipSeconds, el);
    const res = await fetch(`/api/record/${kind}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pcm }),
    });
    const j = await res.json();
    el.textContent = j.ok ? `saved ${j.path}` : j.error;
    await refresh();
  } catch (err) {
    el.textContent = err.message;
  }
  btn.disabled = false;
}

$("btnSpeech").addEventListener("click", () => recordKind("speech"));
$("btnNoise").addEventListener("click", () => recordKind("noise"));

$("btnMix").addEventListener("click", async () => {
  $("trainLog").textContent = "mixing…";
  const j = await (await fetch("/api/mix", { method: "POST" })).json();
  $("trainLog").textContent = j.ok ? `mixed ${j.clips} clips from ${j.speech_files} speech + ${j.noise_files} noise` : j.error;
  await refresh();
});

$("btnTrain").addEventListener("click", async () => {
  $("trainLog").textContent = "training on CPU — this can take a minute…";
  $("btnTrain").disabled = true;
  try {
    const j = await (await fetch("/api/train", { method: "POST" })).json();
    $("trainLog").textContent = j.log || j.error || JSON.stringify(j);
    await refresh();
  } catch (err) {
    $("trainLog").textContent = err.message;
  }
  $("btnTrain").disabled = false;
});

function draw(id, hop, color) {
  const c = $(id);
  const w = c.clientWidth || 400;
  const h = 88;
  if (c.width !== w * 2) {
    c.width = w * 2;
    c.height = h * 2;
  }
  const ctx = c.getContext("2d");
  ctx.setTransform(2, 0, 0, 2, 0, 0);
  ctx.fillStyle = "#243826";
  ctx.fillRect(0, 0, w, h);
  ctx.strokeStyle = color;
  ctx.beginPath();
  for (let x = 0; x < w; x++) {
    const s = hop[Math.floor((x / w) * hop.length)] || 0;
    const y = h / 2 - s * h * 0.42;
    if (x === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();
}

function playHop(pcm) {
  if (!recState.play) return;
  const ctx = recState.play;
  let data = pcm;
  if (Math.abs(ctx.sampleRate - SR) > 50) data = resampleLinear(pcm, SR, ctx.sampleRate);
  const buf = ctx.createBuffer(1, data.length, ctx.sampleRate);
  buf.getChannelData(0).set(data);
  const src = ctx.createBufferSource();
  src.buffer = buf;
  src.connect(ctx.destination);
  const now = ctx.currentTime;
  if (recState.nextT < now + 0.03) recState.nextT = now + 0.03;
  src.start(recState.nextT);
  recState.nextT += data.length / ctx.sampleRate;
}

async function startLive() {
  $("liveStat").textContent = "allow mic…";
  const stream = await navigator.mediaDevices.getUserMedia({
    audio: { echoCancellation: true, noiseSuppression: false, autoGainControl: false },
  });
  recState.stream = stream;
  recState.play = new AudioContext();
  recState.nextT = 0;
  await recState.play.resume();
  const cap = new AudioContext();
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${proto}://${location.host}/ws/live`);
  ws.binaryType = "arraybuffer";
  await new Promise((res, rej) => {
    ws.onopen = res;
    ws.onerror = () => rej(new Error("websocket failed — is serve.py running?"));
  });
  recState.ws = ws;
  recState.running = true;
  const src = cap.createMediaStreamSource(stream);
  const node = cap.createScriptProcessor(2048, 1, 1);
  node.onaudioprocess = (ev) => {
    if (!recState.running || ws.readyState !== 1) return;
    const pcm = resampleLinear(ev.inputBuffer.getChannelData(0), cap.sampleRate, SR);
    ws.send(new Float32Array(pcm).buffer);
  };
  ws.onmessage = (ev) => {
    const msg = JSON.parse(ev.data);
    if (msg.type === "saved") {
      $("liveStat").textContent = msg.pair
        ? `saved ${msg.pair.id} (${msg.pair.seconds}s raw + clean)`
        : "session too short to save";
      refresh();
      return;
    }
    if (msg.type !== "hops") return;
    for (const h of msg.hops) {
      draw("waveIn", h.pcm_in, "#DCE8D4");
      draw("waveOut", h.pcm, "#FFFFFF");
      $("liveGate").textContent = h.gate_open
        ? `SPEECH · open (GRU ${h.tiny_vad == null ? "n/a" : h.tiny_vad.toFixed(2)})`
        : `no speech · ${h.gate_db.toFixed(0)} dB`;
      playHop(Float32Array.from(h.pcm));
    }
  };
  const mute = cap.createGain();
  mute.gain.value = 0;
  src.connect(node);
  node.connect(mute);
  mute.connect(cap.destination);
  recState.cap = cap;
  recState.node = node;
  recState.src = src;
  $("btnLive").disabled = true;
  $("btnStop").disabled = false;
  $("liveStat").textContent = "LIVE · stop to save raw+cleaned pair into data/pairs/";
}

function stopLive() {
  recState.running = false;
  try {
    if (recState.ws && recState.ws.readyState === 1) recState.ws.send("save");
  } catch (e) {}
  setTimeout(() => {
    try { recState.ws && recState.ws.close(); } catch (e) {}
    try {
      recState.node && recState.node.disconnect();
      recState.src && recState.src.disconnect();
      recState.cap && recState.cap.close();
      recState.play && recState.play.close();
    } catch (e) {}
    if (recState.stream) recState.stream.getTracks().forEach((t) => t.stop());
    $("btnLive").disabled = false;
    $("btnStop").disabled = true;
    refresh();
  }, 250);
}

$("btnPair").addEventListener("click", async () => {
  const el = $("liveStat");
  $("btnPair").disabled = true;
  try {
    const pcm = await captureSeconds(clipSeconds, el);
    el.textContent = "cleaning + saving pair…";
    const j = await (await fetch("/api/pair", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pcm }),
    })).json();
    el.textContent = j.ok ? `saved ${j.pair.id} (${j.pair.seconds}s raw + clean)` : (j.error || "save failed");
    await refresh();
  } catch (err) {
    el.textContent = err.message;
  }
  $("btnPair").disabled = false;
});
$("btnLive").addEventListener("click", () => startLive().catch((e) => { $("liveStat").textContent = e.message; }));
$("btnStop").addEventListener("click", stopLive);
refresh();
