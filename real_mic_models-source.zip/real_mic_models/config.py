"""Real-microphone TinyML project.

Honesty:
  REAL        — audio captured from a physical microphone
  MIXED       — real speech + real noise added in software at a known SNR
                (still additive mixing, not a dual-mic field recording)
  Not this    — DRDO field tapes, analog ANC, LibriSpeech download by default
"""

from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
SPEECH_DIR = DATA / "speech"
NOISE_DIR = DATA / "noise"
MIXED_DIR = DATA / "mixed"
PAIRS_DIR = DATA / "pairs"
MODELS = ROOT / "models"
FRONTEND = ROOT / "frontend"

SAMPLE_RATE = 16000
N_FFT = 512
HOP = 256
WIN_LENGTH = 512
N_BANDS = 32
HIDDEN = 48

CLIP_SECONDS = 4.0
MIX_SECONDS = 2.0
SNR_DB = (-5.0, 0.0, 5.0, 10.0, 15.0)
NOISE_ONLY_EVERY = 6
