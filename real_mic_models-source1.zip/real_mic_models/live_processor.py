"""Two-microphone live processor.

Input is pcm_2ch with shape (samples, 2) in USB/hardware order:

    speech    = pcm_2ch[:, SPEECH_CHANNEL]
    reference = pcm_2ch[:, REFERENCE_CHANNEL]

TinyML / Wiener / gate run on `speech` only.
`reference` is never averaged in and is returned untouched for a future LMS stage.
"""

from __future__ import annotations

import time

import numpy as np

from audio_io import split_channels, split_pcm_2ch
from config import SAMPLE_RATE, channel_config
from enhance import RealMicEnhancer


class TwoMicProcessor:
    """Speech channel → TinyML. Reference channel preserved."""

    def __init__(self) -> None:
        self.speech = RealMicEnhancer()
        self.cfg = channel_config()
        self.ref_buf = np.zeros(0, dtype=np.float64)

    def reset(self) -> None:
        self.speech.reset()
        self.ref_buf = np.zeros(0, dtype=np.float64)
        self.cfg = channel_config()

    def process_pcm_2ch(self, pcm_2ch: np.ndarray, *, hardware_order: bool = True) -> list[dict]:
        """pcm_2ch: (N, 2) or interleaved (2N,).

        hardware_order=True  — columns are USB ch0/ch1; split with SPEECH_CHANNEL.
        hardware_order=False — columns are already [speech, reference].
        """
        t0 = time.perf_counter()
        if hardware_order:
            speech, reference = split_pcm_2ch(pcm_2ch)
        else:
            speech, reference = split_channels(pcm_2ch)
        hops = self.speech.process_block(speech)
        self.ref_buf = np.concatenate([self.ref_buf, np.asarray(reference, dtype=np.float64)])
        out = []
        for h in hops:
            n = len(h["pcm_in"])
            if len(self.ref_buf) < n:
                ref_hop = np.pad(self.ref_buf, (0, n - len(self.ref_buf)))
                self.ref_buf = np.zeros(0, dtype=np.float64)
            else:
                ref_hop = self.ref_buf[:n]
                self.ref_buf = self.ref_buf[n:]
            latency_ms = round(1000.0 * (time.perf_counter() - t0) / max(len(hops), 1), 3)
            out.append(
                {
                    "speech_raw": h["pcm_in"],
                    "reference_raw": np.asarray(ref_hop, dtype=np.float32).tolist(),
                    "speech_clean": h["pcm"],
                    "tiny_vad": h["tiny_vad"],
                    "gate_open": h["gate_open"],
                    "gate_db": h["gate_db"],
                    "ml": h["ml"],
                    "latency_ms": latency_ms,
                    "sample_rate": SAMPLE_RATE,
                    "channels": 2,
                    "tiny_ml_input": "speech_channel_only",
                    "speech_channel": int(channel_config()["speech_channel"]),
                    "reference_channel": int(channel_config()["reference_channel"]),
                }
            )
        return out

    def process_stereo_block(self, stereo: np.ndarray) -> list[dict]:
        """Back-compat: treat as hardware-order pcm_2ch."""
        return self.process_pcm_2ch(stereo, hardware_order=True)

    def process_full_stereo(self, speech: np.ndarray, reference: np.ndarray) -> dict:
        """Already-split arrays (canonical speech / reference)."""
        n = min(len(speech), len(reference))
        stereo = np.stack(
            [np.asarray(speech[:n], dtype=np.float32), np.asarray(reference[:n], dtype=np.float32)],
            axis=1,
        )
        hops = self.process_pcm_2ch(stereo, hardware_order=False)
        if not hops:
            z = np.zeros(0, dtype=np.float32)
            return {
                "speech_raw": z,
                "reference_raw": z,
                "speech_clean": z,
                "tiny_vad": None,
                "gate_open": False,
                "latency_ms": 0.0,
                "sample_rate": SAMPLE_RATE,
                "channels": 2,
                "ml": bool(self.speech.tiny.ok),
            }
        return {
            "speech_raw": np.concatenate([np.asarray(h["speech_raw"], dtype=np.float32) for h in hops]),
            "reference_raw": np.concatenate([np.asarray(h["reference_raw"], dtype=np.float32) for h in hops]),
            "speech_clean": np.concatenate([np.asarray(h["speech_clean"], dtype=np.float32) for h in hops]),
            "tiny_vad": hops[-1]["tiny_vad"],
            "gate_open": hops[-1]["gate_open"],
            "latency_ms": hops[-1]["latency_ms"],
            "sample_rate": SAMPLE_RATE,
            "channels": 2,
            "ml": hops[-1]["ml"],
        }
