"""Capture a short two-channel clip from PortAudio (Windows / Pi / macOS).

Used by audio_device_test.py and record_test.py. The website uses the
browser microphone instead; this path is for Raspberry Pi and diagnostics.
"""

from __future__ import annotations

import numpy as np

from audio_io import resample_to_16k
from config import SAMPLE_RATE, channel_config
from devices import pick_two_channel_device


def record_stereo_seconds(seconds: float = 4.0, device_index: int | None = None) -> dict:
    """Return speech, reference arrays at 16 kHz plus device metadata.

    Raises RuntimeError with a beginner message if sounddevice is missing
    or the selected device has fewer than 2 input channels.
    """
    picked = pick_two_channel_device(device_index)
    if not picked.get("ok"):
        raise RuntimeError(picked.get("error") or "No two-channel input device.")
    try:
        import sounddevice as sd
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(
            f"sounddevice is not installed ({exc}). pip install sounddevice. "
            "On Raspberry Pi also run: sudo apt install libportaudio2"
        ) from exc

    device = picked["device"]
    idx = int(device["index"])
    n_in = int(device["max_input_channels"])
    native_sr = int(device["default_samplerate"] or SAMPLE_RATE)
    frames = int(max(1.0, seconds) * native_sr)
    rec = sd.rec(frames, samplerate=native_sr, channels=min(n_in, 2), device=idx, dtype="float32")
    sd.wait()
    rec = np.asarray(rec, dtype=np.float64)
    if rec.ndim == 1:
        rec = rec.reshape(-1, 1)
    if rec.shape[1] < 2:
        raise RuntimeError(
            "Recording came back with fewer than 2 channels. "
            "Connect both microphones to the same multi-channel USB audio interface."
        )
    stereo = resample_to_16k(rec, native_sr).astype(np.float32)
    cfg = channel_config()
    s_i = min(int(cfg["speech_channel"]), stereo.shape[1] - 1)
    r_i = min(int(cfg["reference_channel"]), stereo.shape[1] - 1)
    speech = stereo[:, s_i]
    reference = stereo[:, r_i]
    return {
        "speech": speech,
        "reference": reference,
        "sample_rate": SAMPLE_RATE,
        "native_sample_rate": native_sr,
        "device": device,
        "seconds": round(len(speech) / SAMPLE_RATE, 3),
        "rms_speech": float(np.sqrt(np.mean(speech ** 2))),
        "rms_reference": float(np.sqrt(np.mean(reference ** 2))),
    }
