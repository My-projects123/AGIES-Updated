"""Data augmentation on REAL-mic mixes.

Applied to the *noisy* input (and, for reverb, to the clean target with the
same IR so the net is not asked to dereverb). Clipping and extra noise hit
only the input — that is the mismatch the model must learn to invert.
"""

from __future__ import annotations

import numpy as np

from config import SAMPLE_RATE


def reverb(x: np.ndarray, rt60_s: float, sr: int = SAMPLE_RATE, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    n = max(8, int(rt60_s * sr))
    ir = rng.standard_normal(n) * np.exp(-6.9 * np.arange(n) / n)
    ir[0] = 1.0
    ir /= np.sqrt(np.sum(ir ** 2)) + 1e-12
    return np.convolve(x, ir, mode="full")[: len(x)]


def clip_soft(x: np.ndarray, limit: float) -> np.ndarray:
    return np.clip(x, -limit, limit)


def mix_at_snr(clean: np.ndarray, noise: np.ndarray, snr_db: float) -> np.ndarray:
    c_pow = float(np.mean(clean ** 2) + 1e-12)
    d_pow = float(np.mean(noise ** 2) + 1e-12)
    scale = np.sqrt(c_pow / (d_pow * (10.0 ** (snr_db / 10.0))))
    return clean + scale * noise


def augment_pair(
    clean: np.ndarray,
    noisy: np.ndarray,
    rng: np.random.Generator,
    seed: int,
) -> tuple[np.ndarray, np.ndarray]:
    """Return (noisy_aug, clean_aug)."""
    noisy = noisy.copy()
    clean = clean.copy()
    # random level (both tracks, so SNR is unchanged)
    if rng.random() < 0.8:
        g = float(rng.uniform(0.25, 1.0))
        noisy *= g
        clean *= g
    # short room on both — target stays matched
    if rng.random() < 0.35:
        rt = float(rng.uniform(0.12, 0.40))
        noisy = reverb(noisy, rt, SAMPLE_RATE, seed)
        clean = reverb(clean, rt, SAMPLE_RATE, seed)
    # extra noise burst already in the mix; mild extra pink on input only
    if rng.random() < 0.25:
        pink = rng.standard_normal(len(noisy)).astype(np.float64)
        # leaky integrator ≈ pink
        for i in range(1, len(pink)):
            pink[i] = 0.95 * pink[i - 1] + 0.05 * pink[i]
        noisy = noisy + 0.02 * pink * (np.sqrt(np.mean(noisy ** 2)) + 1e-12)
    # ADC / radio clipping on the observed mix only
    if rng.random() < 0.20:
        noisy = clip_soft(noisy, float(rng.uniform(0.55, 0.95)))
    return noisy.astype(np.float32), clean.astype(np.float32)
