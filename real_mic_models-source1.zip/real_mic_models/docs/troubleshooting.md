# Troubleshooting

## Browser says 1 channel / rejects the recording

**Cause:** built-in laptop mic, or Windows using the wrong default device.  
**Do:** plug both mics into **one** USB interface. In STEP 1 pick that interface. Chrome: `chrome://settings/content/microphone`.

Message we show on purpose:

> Connect both microphones to the same multi-channel USB audio interface.

## Both meters move the same

The OS may be duplicating a mono device into “stereo”. That is still one microphone. Use a real 2-in interface. Confirm with `python audio_device_test.py`.

## Speech and reference swapped

STEP 2 → swap the two dropdowns → SAVE CHANNEL MAP. Or set in `config.py`:

```
SPEECH_CHANNEL = 1
REFERENCE_CHANNEL = 0
```

## `ERR_CONNECTION_REFUSED`

`serve.py` is not running. Start it and leave the window open. Default port **8090**.

```bat
set PORT=8091
python serve.py
```

## Train: “No speech WAVs”

Record STEP 3 at least 4 speech + 4 noise clips (8+ is better), then BUILD DATASET.

## No ONNX / TinyML loaded: False

Train, or copy `models/real_mic.int8.onnx` onto the machine. Live mode still runs Wiener + gate (**DSP fallback**). That is intentional.

## Raspberry Pi: `sounddevice` import error

```bash
sudo apt install libportaudio2
source .venv/bin/activate
pip install sounddevice
```

## Raspberry Pi: `arecord -l` empty

Replug USB, try a powered hub, `dmesg | tail`. Some interfaces need `otg` / USB2 ports.

## INT8 missing, only FP32

Quantization needs `onnxruntime` quantization extras. Live still works with `real_mic.onnx`. Pi prefers INT8 when present.

## pytest skipped ONNX tests

Normal before the first train. After `python train.py` they should run.

## Never claim

- Analog ANC
- DCCRN / MacBook stage
- Field DRDO scores
- 15 dB / 0.85 / 2.5 unless `evaluate.py` actually printed them as MEASURED
