"""Project settings for the real-microphone TinyML project.

Honesty labels (use these words in the UI and docs):
  REAL        — audio captured from a physical microphone
  MIXED       — real speech + real noise added in software at a known SNR
                (NOT a true simultaneous two-mic field recording)
  SIMULATED   — synthetic talkers (the original AEGIS-COM POC, not this folder)
  TARGET      — a goal number that has not been measured yet
  MEASURED    — a number we actually computed on a test set

This file is the only place you should change channel numbers.
Do not put microphone brand names here. Any USB interface is fine
as long as it presents TWO input channels to the computer.
"""

from __future__ import annotations

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
SPEECH_DIR = DATA / "speech"          # Path A: quiet-room speech (often mono)
NOISE_DIR = DATA / "noise"            # Path A: room noise (often mono)
MIXED_DIR = DATA / "mixed"            # Path A: software additive mixes
PAIRS_DIR = DATA / "pairs"            # live raw + cleaned takes
DUAL_MIC_DIR = DATA / "dual_mic"
DUAL_SYNC_DIR = DUAL_MIC_DIR / "synchronized"  # Path B: true 2-channel WAVs
DUAL_SPEECH_DIR = DUAL_MIC_DIR / "speech"      # extracted speech channel
DUAL_REF_DIR = DUAL_MIC_DIR / "reference"      # extracted reference channel
MANIFESTS_DIR = DATA / "manifests"
RECORDINGS_DIR = ROOT / "recordings"  # diagnostic clips (record_test.py)
MODELS = ROOT / "models"
FRONTEND = ROOT / "frontend"
DOCS = ROOT / "docs"

# TinyMaskNet — keep these identical to the SIH POC so ONNX still matches.
SAMPLE_RATE = 16000
N_FFT = 512
HOP = 256
WIN_LENGTH = 512
N_BANDS = 32
HIDDEN = 48
N_CHANNELS = 2

# Channel roles. 0 = first channel the USB interface reports (usually Left).
# Swap these two numbers (or use the website dropdown) if your cables are reversed.
# TinyML cleans SPEECH_CHANNEL only. REFERENCE_CHANNEL is stored for a future LMS stage.
SPEECH_CHANNEL = 0
REFERENCE_CHANNEL = 1

CLIP_SECONDS = 4.0
MIX_SECONDS = 2.0
SNR_DB = (-5.0, 0.0, 5.0, 10.0, 15.0)
NOISE_ONLY_EVERY = 6

# None = "use the OS default input". Set to an integer device index after
# running:  python audio_device_test.py
AUDIO_DEVICE_INDEX: int | None = None

CHANNEL_CONFIG_PATH = MANIFESTS_DIR / "channel_config.json"


def channel_config() -> dict:
    """Runtime channel map. File overlay wins over the defaults above."""
    cfg = {
        "speech_channel": int(SPEECH_CHANNEL),
        "reference_channel": int(REFERENCE_CHANNEL),
        "n_channels": int(N_CHANNELS),
        "sample_rate": int(SAMPLE_RATE),
        "audio_device_index": AUDIO_DEVICE_INDEX,
        "tiny_ml_input": "speech_channel_only",
        "note": (
            "TinyML currently cleans the speech channel. "
            "The synchronized reference channel is preserved for the next adaptive/LMS stage."
        ),
    }
    if CHANNEL_CONFIG_PATH.exists():
        try:
            overlay = json.loads(CHANNEL_CONFIG_PATH.read_text())
            for key in ("speech_channel", "reference_channel", "audio_device_index"):
                if key in overlay:
                    cfg[key] = overlay[key]
        except json.JSONDecodeError:
            pass
    return cfg


def save_channel_config(speech_channel: int, reference_channel: int, audio_device_index: int | None = None) -> dict:
    if speech_channel == reference_channel:
        raise ValueError("Speech and reference must be different channel numbers (0 and 1).")
    if speech_channel not in (0, 1) or reference_channel not in (0, 1):
        raise ValueError("Channel numbers must be 0 or 1 in this stage.")
    MANIFESTS_DIR.mkdir(parents=True, exist_ok=True)
    cfg = channel_config()
    cfg["speech_channel"] = int(speech_channel)
    cfg["reference_channel"] = int(reference_channel)
    if audio_device_index is not None:
        cfg["audio_device_index"] = int(audio_device_index)
    CHANNEL_CONFIG_PATH.write_text(json.dumps(cfg, indent=2))
    return cfg


def ensure_data_dirs() -> None:
    for folder in (
        SPEECH_DIR,
        NOISE_DIR,
        MIXED_DIR,
        PAIRS_DIR,
        DUAL_SYNC_DIR,
        DUAL_SPEECH_DIR,
        DUAL_REF_DIR,
        MANIFESTS_DIR,
        RECORDINGS_DIR,
        MODELS,
    ):
        folder.mkdir(parents=True, exist_ok=True)
