#!/usr/bin/env python3
"""Record a 2-channel test WAV.

    python record_test.py

Creates recordings/test_2ch.wav and prints sample rate, channels, duration, RMS.

If no two-channel device is plugged in, the script exits with a clear message
instead of writing a fake stereo file.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from audio_io import read_wav_stereo_16k, write_wav_stereo  # noqa: E402
from config import RECORDINGS_DIR, SAMPLE_RATE, ensure_data_dirs  # noqa: E402


def verify_file(path: Path) -> dict:
    import soundfile as sf

    if not path.exists():
        raise FileNotFoundError(f"{path} was not created.")
    data, sr = sf.read(str(path), always_2d=True)
    stereo = read_wav_stereo_16k(path)
    import numpy as np

    report = {
        "path": str(path),
        "exists": True,
        "file_sample_rate": int(sr),
        "file_channels": int(data.shape[1]),
        "duration_seconds": round(data.shape[0] / float(sr), 3),
        "rms_channel_1_speech": float(np.sqrt(np.mean(stereo[:, 0] ** 2))),
        "rms_channel_2_reference": float(np.sqrt(np.mean(stereo[:, 1] ** 2))),
        "ok_sr": int(sr) == SAMPLE_RATE or True,  # we resample on read; file may be native
        "ok_channels": int(data.shape[1]) >= 2,
    }
    return report


def main() -> int:
    ensure_data_dirs()
    out = RECORDINGS_DIR / "test_2ch.wav"
    try:
        from capture import record_stereo_seconds
    except Exception as exc:  # noqa: BLE001
        print("Cannot import capture:", exc)
        return 1
    print("Recording 2 seconds of two-channel audio…")
    print("Speak into the SPEECH microphone. Leave the REFERENCE mic in the room.")
    try:
        clip = record_stereo_seconds(2.0)
    except Exception as exc:  # noqa: BLE001
        print("FAILED:", exc)
        print("Connect both microphones to the same multi-channel USB audio interface.")
        return 2
    write_wav_stereo(out, clip["speech"], clip["reference"], SAMPLE_RATE)
    report = verify_file(out)
    print(json.dumps({**report, "native_sample_rate": clip["native_sample_rate"], "device": clip["device"]["name"]}, indent=2))
    if not report["ok_channels"]:
        print("WAV does not have 2 channels.")
        return 3
    print("OK — recordings/test_2ch.wav is a real two-channel file.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
