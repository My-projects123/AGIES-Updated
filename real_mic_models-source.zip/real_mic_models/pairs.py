"""Paired dataset: REAL raw mic + cleaned mic, same take.

Each clip is two 16 kHz WAVs plus a row in index.json:
  data/pairs/{id}_raw.wav     what the microphone captured
  data/pairs/{id}_clean.wav   same samples after Wiener × TinyML × gate
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np

from audio_io import write_wav
from config import PAIRS_DIR, SAMPLE_RATE

INDEX = PAIRS_DIR / "index.json"


def _load() -> list[dict]:
    if not INDEX.exists():
        return []
    return json.loads(INDEX.read_text())


def _save(rows: list[dict]) -> None:
    PAIRS_DIR.mkdir(parents=True, exist_ok=True)
    INDEX.write_text(json.dumps(rows, indent=2))


def list_pairs() -> list[dict]:
    return _load()


def save_pair(raw: np.ndarray, clean: np.ndarray, source: str = "live") -> dict:
    raw = np.asarray(raw, dtype=np.float32).reshape(-1)
    clean = np.asarray(clean, dtype=np.float32).reshape(-1)
    n = min(len(raw), len(clean))
    if n < SAMPLE_RATE // 2:
        raise ValueError("clip too short to save (need ≥ 0.5 s)")
    raw, clean = raw[:n], clean[:n]
    pid = f"pair_{int(time.time() * 1000)}"
    PAIRS_DIR.mkdir(parents=True, exist_ok=True)
    raw_name = f"{pid}_raw.wav"
    clean_name = f"{pid}_clean.wav"
    write_wav(PAIRS_DIR / raw_name, raw)
    write_wav(PAIRS_DIR / clean_name, clean)
    row = {
        "id": pid,
        "source": source,
        "seconds": round(n / SAMPLE_RATE, 2),
        "samples": int(n),
        "sr": SAMPLE_RATE,
        "raw": raw_name,
        "clean": clean_name,
        "raw_url": f"/pairs/{raw_name}",
        "clean_url": f"/pairs/{clean_name}",
        "note": "REAL mic raw + processed clean of the same take",
    }
    rows = _load()
    rows.append(row)
    _save(rows)
    return row
