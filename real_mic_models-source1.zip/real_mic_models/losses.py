"""Training losses for the TinyML masker.

The net predicts a 32-band gain, not a waveform. Losses are therefore applied
to the *masked noisy bands* vs the *clean bands*:

  estimated speech spectrum  = gain  × noisy_bands
  target speech spectrum     = IRM   × noisy_bands   (= clean_bands)

SI-SNR is the scale-invariant time-frequency analogue (Luo & Mesgarani).
L1 / L2 are on compressed magnitudes (closer to loudness than raw FFT bins).
Perceptual loss is speech-band-weighted log-magnitude L1 — not a large
pretrained network; that would not fit a 13k-parameter Pi model.
"""

from __future__ import annotations

import torch
from torch import nn

from fbanks import band_centers_hz


COMPRESS = 0.3  # power-law magnitude compression


def _flat(x: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
    """Flatten time×bands, masked by hop weight [B, T, 1]."""
    w = weight.expand_as(x)
    return (x * w).reshape(x.shape[0], -1), w.reshape(x.shape[0], -1)


def l2_loss(est: torch.Tensor, tgt: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
    e, w = _flat(est, weight)
    t, _ = _flat(tgt, weight)
    denom = w.sum().clamp(min=1.0)
    return ((e - t) ** 2).sum() / denom


def l1_loss(est: torch.Tensor, tgt: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
    e, w = _flat(est, weight)
    t, _ = _flat(tgt, weight)
    denom = w.sum().clamp(min=1.0)
    return (e - t).abs().sum() / denom


def si_snr_loss(est: torch.Tensor, tgt: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
    """Negative SI-SNR in dB (lower is better). Zero-mean over active hops."""
    # [B, T, F] → [B, TF] with inactive hops zeroed so they do not dominate
    e = (est * weight).reshape(est.shape[0], -1)
    t = (tgt * weight).reshape(tgt.shape[0], -1)
    e = e - e.mean(dim=1, keepdim=True)
    t = t - t.mean(dim=1, keepdim=True)
    dot = (e * t).sum(dim=1, keepdim=True)
    t_pow = (t ** 2).sum(dim=1, keepdim=True).clamp(min=1e-8)
    s_target = (dot / t_pow) * t
    err = e - s_target
    snr = 10.0 * torch.log10(
        (s_target ** 2).sum(dim=1).clamp(min=1e-8) / (err ** 2).sum(dim=1).clamp(min=1e-8)
    )
    return -snr.mean()


def perceptual_loss(est: torch.Tensor, tgt: torch.Tensor, weight: torch.Tensor) -> torch.Tensor:
    """Speech-band-weighted log-magnitude L1 (300–3400 Hz emphasized)."""
    centers = torch.from_numpy(band_centers_hz().astype("float32")).to(est.device)
    w_f = torch.where((centers >= 300.0) & (centers <= 3400.0), torch.tensor(2.5, device=est.device), torch.tensor(0.6, device=est.device))
    log_e = torch.log(est.clamp(min=1e-8))
    log_t = torch.log(tgt.clamp(min=1e-8))
    diff = (log_e - log_t).abs() * w_f.view(1, 1, -1)
    return (diff * weight).sum() / weight.expand_as(diff).sum().clamp(min=1.0)


def compress(mag: torch.Tensor) -> torch.Tensor:
    return mag.clamp(min=0.0) ** COMPRESS


class CombinedLoss(nn.Module):
    """λ_si·SI-SNR + λ_l1·L1 + λ_l2·L2 + λ_perc·perceptual + λ_vad·BCE."""

    def __init__(
        self,
        w_si: float = 0.15,
        w_l1: float = 0.25,
        w_l2: float = 0.25,
        w_perc: float = 0.20,
        w_vad: float = 0.50,
    ) -> None:
        super().__init__()
        self.w_si = w_si
        self.w_l1 = w_l1
        self.w_l2 = w_l2
        self.w_perc = w_perc
        self.w_vad = w_vad
        self.bce = nn.BCELoss()

    def forward(
        self,
        gain: torch.Tensor,
        vad: torch.Tensor,
        irm: torch.Tensor,
        noisy_bands: torch.Tensor,
        vad_tgt: torch.Tensor,
        hop_w: torch.Tensor,
    ) -> tuple[torch.Tensor, dict[str, float]]:
        est = gain * noisy_bands
        tgt = irm * noisy_bands
        est_c = compress(est)
        tgt_c = compress(tgt)
        si = si_snr_loss(est, tgt, hop_w)
        l1 = l1_loss(est_c, tgt_c, hop_w)
        l2 = l2_loss(est_c, tgt_c, hop_w)
        perc = perceptual_loss(est, tgt, hop_w)
        vad_l = self.bce((vad * hop_w).clamp(1e-6, 1 - 1e-6), vad_tgt * hop_w)
        total = self.w_si * si + self.w_l1 * l1 + self.w_l2 * l2 + self.w_perc * perc + self.w_vad * vad_l
        parts = {
            "si_snr": float(-si.detach()),  # report as improvement-style dB (higher better)
            "l1": float(l1.detach()),
            "l2": float(l2.detach()),
            "perceptual": float(perc.detach()),
            "vad": float(vad_l.detach()),
            "total": float(total.detach()),
        }
        return total, parts
