"""List audio input devices. Brand-agnostic.

This module never mentions Focusrite, Behringer, BOYA, RODE, or Shure.
Whatever name the operating system reports is what we print.
"""

from __future__ import annotations

from config import SAMPLE_RATE, channel_config


def sounddevice_status() -> dict:
    try:
        import sounddevice as sd  # noqa: F401
    except Exception as exc:  # noqa: BLE001
        return {
            "available": False,
            "reason": str(exc),
            "hint": "pip install sounddevice   (needs PortAudio; on Raspberry Pi: sudo apt install libportaudio2)",
        }
    return {"available": True, "reason": None}


def list_input_devices() -> dict:
    """Return every input device PortAudio can see, plus whether 2 channels exist."""
    st = sounddevice_status()
    if not st["available"]:
        return {"ok": False, "error": st["reason"], "hint": st["hint"], "devices": [], "two_channel_available": False}

    import sounddevice as sd

    hostapis = sd.query_hostapis()
    devices = []
    default_in = None
    try:
        default_in = int(sd.default.device[0]) if sd.default.device else None
    except Exception:
        default_in = None
    for i, d in enumerate(sd.query_devices()):
        n_in = int(d.get("max_input_channels") or 0)
        if n_in <= 0:
            continue
        host = ""
        try:
            host = str(hostapis[int(d["hostapi"])]["name"])
        except Exception:
            host = "unknown"
        devices.append(
            {
                "index": i,
                "name": str(d.get("name") or f"device-{i}"),
                "max_input_channels": n_in,
                "default_samplerate": float(d.get("default_samplerate") or 0),
                "hostapi": host,
                "two_channel_ok": n_in >= 2,
                "is_default_input": i == default_in,
            }
        )
    two = [d for d in devices if d["two_channel_ok"]]
    cfg = channel_config()
    selected = cfg.get("audio_device_index")
    if selected is None:
        selected = two[0]["index"] if two else (devices[0]["index"] if devices else None)
    return {
        "ok": True,
        "devices": devices,
        "two_channel_available": bool(two),
        "two_channel_count": len(two),
        "selected_device_index": selected,
        "default_input_index": default_in,
        "sample_rate_wanted": SAMPLE_RATE,
        "channel_config": cfg,
        "warning": None
        if two
        else "Connect both microphones to the same multi-channel USB audio interface.",
    }


def pick_two_channel_device(index: int | None = None) -> dict:
    info = list_input_devices()
    if not info.get("ok"):
        return info
    if index is None:
        index = info.get("selected_device_index")
    match = next((d for d in info["devices"] if d["index"] == index), None)
    if match is None:
        return {"ok": False, "error": f"No input device with index {index}. Run: python audio_device_test.py"}
    if not match["two_channel_ok"]:
        return {
            "ok": False,
            "error": (
                f"Device {index} ({match['name']}) has only {match['max_input_channels']} input channel(s). "
                "Connect both microphones to the same multi-channel USB audio interface."
            ),
            "device": match,
        }
    return {"ok": True, "device": match}
