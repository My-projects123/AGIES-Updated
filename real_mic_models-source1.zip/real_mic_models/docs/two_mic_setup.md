# Two-microphone setup

## Roles (not brands)

| Role | Config name | Default index | Where to put it |
|---|---|---|---|
| Speech microphone | `SPEECH_CHANNEL` | 0 | Close to the talker’s mouth |
| Reference / environment microphone | `REFERENCE_CHANNEL` | 1 | Aimed at the room / noise, not the mouth |

Any USB interface that shows **two input channels** is fine. Do not use two separate USB microphones — they have two clocks and will drift.

Change the mapping in the website (STEP 2) or in `config.py`. TinyML code never contains BOYA, RODE, Focusrite, or similar names.

## What TinyML sees

```
pcm_2ch  shape (samples, 2)   # USB / hardware order
speech     = pcm_2ch[:, SPEECH_CHANNEL]      # default 0
reference  = pcm_2ch[:, REFERENCE_CHANNEL]   # default 1

speech  → TinyML (32-band GRU) → clean speech
reference is stored. The two channels are NEVER averaged.
```

```
TinyML currently cleans the speech channel.
The synchronized reference channel is preserved for the next adaptive/LMS stage.
```

Input tensor: `bands` shape `(1, 1, 32)` — log filterbank of **one** hop of the speech mic.

Outputs: `gain (1,1,32)`, `vad (1,1,1)`, `h_out (1,1,48)`.

Optional two-channel TinyML (concatenating both mics into the GRU) is **not enabled**. It would change the ONNX graph and the 13k-parameter budget. Leave it for a later experiment.

## Path A vs Path B

**Path A — controlled mix (training)**  
Record speech (quiet room) and noise (nobody talking). Software adds them at a known SNR. Label: **MIXED**. Needed because the clean target is known.

**Path B — two-mic real recording**  
One stereo WAV: column 0 speech, column 1 reference (after remap). Label: **REAL**. Used for live processing and for a future LMS stage. Not used as TinyML’s clean target yet (there is no separate clean reference in a live room).

## Hardware checklist

1. One USB audio interface with ≥ 2 inputs.
2. Mic A → input 1 (speech).
3. Mic B → input 2 (reference).
4. Same sample-rate family (48 kHz on the box is OK; software resamples each channel to 16 kHz **separately**).
5. Headphones on the Pi or laptop for the cleaned speech. Do not use Bluetooth in this stage.
