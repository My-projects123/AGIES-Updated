"""Record real-mic speech/noise, mix, train, live-clean."""

from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path

import numpy as np
from fastapi import FastAPI, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from audio_io import list_wavs, write_wav
from config import CLIP_SECONDS, FRONTEND, NOISE_DIR, PAIRS_DIR, SAMPLE_RATE, SPEECH_DIR
from enhance import RealMicEnhancer
from infer import TinyInfer
from mix_dataset import build_dataset
from pairs import list_pairs, save_pair
from paths import MANIFEST, META_JSON

ROOT = Path(__file__).resolve().parent
app = FastAPI(title="AEGIS real-mic TinyML")
app.mount("/static", StaticFiles(directory=str(FRONTEND)), name="static")
PAIRS_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/pairs", StaticFiles(directory=str(PAIRS_DIR)), name="pairs")

_status = {"busy": False, "log": "idle"}


class PcmIn(BaseModel):
    pcm: list[float]


def _counts() -> dict:
    return {
        "speech": len(list_wavs(SPEECH_DIR)),
        "noise": len(list_wavs(NOISE_DIR)),
        "mixed": json.loads(MANIFEST.read_text())["clips"] if MANIFEST.exists() else 0,
        "pairs": len(list_pairs()),
        "pair_list": list_pairs()[-20:],
        "trained": META_JSON.exists(),
        "model": json.loads(META_JSON.read_text()) if META_JSON.exists() else None,
        "infer": TinyInfer().status(),
        "busy": _status["busy"],
        "log": _status["log"],
        "clip_seconds": CLIP_SECONDS,
        "sr": SAMPLE_RATE,
    }


@app.get("/")
def index():
    return FileResponse(FRONTEND / "index.html")


@app.get("/api/status")
def status():
    return _counts()


@app.post("/api/record/{kind}")
async def record(kind: str, body: PcmIn):
    if kind not in ("speech", "noise"):
        return {"ok": False, "error": "kind must be speech or noise"}
    pcm = np.asarray(body.pcm, dtype=np.float32)
    if pcm.size < SAMPLE_RATE:
        return {"ok": False, "error": "clip too short"}
    folder = SPEECH_DIR if kind == "speech" else NOISE_DIR
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{kind}_{int(time.time() * 1000)}.wav"
    write_wav(path, pcm, SAMPLE_RATE)
    return {"ok": True, "path": path.name, **_counts()}


@app.get("/api/pairs")
def pairs():
    return {"ok": True, "pairs": list_pairs()}


@app.post("/api/pair")
def pair_from_clip(body: PcmIn):
    """Record raw mic → clean it → save both WAVs as one dataset row."""
    pcm = np.asarray(body.pcm, dtype=np.float32)
    if pcm.size < SAMPLE_RATE:
        return {"ok": False, "error": "clip too short"}
    enh = RealMicEnhancer()
    raw, clean = enh.process_full(pcm)
    try:
        row = save_pair(raw, clean, source="record")
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True, "pair": row, **_counts()}


@app.post("/api/mix")
def mix(n_clips: int = Query(240, ge=16, le=2000)):
    if _status["busy"]:
        return {"ok": False, "error": "busy"}
    try:
        meta = build_dataset(n_clips=n_clips)
        _status["log"] = f"mixed {meta['clips']} clips"
        return {"ok": True, **meta, **_counts()}
    except SystemExit as exc:
        return {"ok": False, "error": str(exc)}


@app.post("/api/train")
def train():
    if _status["busy"]:
        return {"ok": False, "error": "busy"}
    _status["busy"] = True
    _status["log"] = "training…"
    try:
        proc = subprocess.run(
            [sys.executable, str(ROOT / "train.py")],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=600,
        )
        _status["log"] = (proc.stdout or "")[-1500:] + (("\n" + proc.stderr) if proc.stderr else "")
        if proc.returncode != 0:
            return {"ok": False, "error": _status["log"], **_counts()}
        return {"ok": True, "log": _status["log"], **_counts()}
    finally:
        _status["busy"] = False


@app.websocket("/ws/live")
async def ws_live(ws: WebSocket):
    await ws.accept()
    enh = RealMicEnhancer()
    raw_chunks: list[np.ndarray] = []
    clean_chunks: list[np.ndarray] = []
    await ws.send_json({"type": "ready", **enh.tiny.status()})

    def flush_pair(source: str) -> dict | None:
        if not raw_chunks:
            return None
        raw = np.concatenate(raw_chunks)
        clean = np.concatenate(clean_chunks)
        raw_chunks.clear()
        clean_chunks.clear()
        try:
            return save_pair(raw, clean, source=source)
        except ValueError:
            return None

    try:
        while True:
            msg = await ws.receive()
            if msg["type"] == "websocket.disconnect":
                row = flush_pair("live")
                break
            data = msg.get("bytes")
            if not data:
                text = msg.get("text")
                if text == "save":
                    row = flush_pair("live")
                    await ws.send_json({"type": "saved", "pair": row})
                continue
            pcm = np.frombuffer(data, dtype=np.float32)
            hops = enh.process_block(pcm)
            if hops:
                for h in hops:
                    raw_chunks.append(np.asarray(h["pcm_in"], dtype=np.float32))
                    clean_chunks.append(np.asarray(h["pcm"], dtype=np.float32))
                await ws.send_json({"type": "hops", "hops": hops})
    except WebSocketDisconnect:
        flush_pair("live")
        return
