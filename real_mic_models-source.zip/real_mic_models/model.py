"""Tiny causal speech-isolation net — same architecture as the SIH POC.

Trained here on REAL microphone speech + REAL microphone noise mixes.
"""

from __future__ import annotations

import torch
from torch import nn

from config import HIDDEN, N_BANDS


class TinyMaskNet(nn.Module):
    def __init__(self, n_bands: int = N_BANDS, hidden: int = HIDDEN) -> None:
        super().__init__()
        self.n_bands = n_bands
        self.hidden = hidden
        self.gru = nn.GRU(n_bands, hidden, num_layers=1, batch_first=True)
        self.fc = nn.Linear(hidden, n_bands)
        self.fc_vad = nn.Linear(hidden, 1)

    def forward(self, bands: torch.Tensor, h: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor, torch.Tensor]:
        y, h_out = self.gru(bands, h)
        return torch.sigmoid(self.fc(y)), torch.sigmoid(self.fc_vad(y)), h_out

    def forward_seq(self, bands: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        y, _ = self.gru(bands)
        return torch.sigmoid(self.fc(y)), torch.sigmoid(self.fc_vad(y))

    def param_count(self) -> int:
        return int(sum(p.numel() for p in self.parameters()))
