"""Device listing must not crash when PortAudio is missing or empty."""

from __future__ import annotations

from devices import list_input_devices, sounddevice_status


def test_list_devices_returns_dict():
    info = list_input_devices()
    assert "devices" in info or "error" in info
    if info.get("ok"):
        assert "two_channel_available" in info
        assert isinstance(info["devices"], list)
    else:
        assert info.get("error")
