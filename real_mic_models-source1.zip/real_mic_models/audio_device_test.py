#!/usr/bin/env python3
"""Print every input device and whether two-channel capture is possible.

    python audio_device_test.py
    python audio_device_test.py --no-capture
    python audio_device_test.py --device 2

--device selects the PortAudio index explicitly (saved into channel_config.json).
Do not assume a microphone brand — names come from the OS.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from config import SAMPLE_RATE, channel_config, save_channel_config  # noqa: E402
from devices import list_input_devices  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--no-capture", action="store_true")
    parser.add_argument("--device", type=int, default=None, help="PortAudio input device index")
    args = parser.parse_args()

    cfg = channel_config()
    print("AEGIS two-microphone device test")
    print("Wanted sample rate:", SAMPLE_RATE)
    print("Channel 1 (index {}) = SPEECH".format(cfg["speech_channel"]))
    print("Channel 2 (index {}) = REFERENCE".format(cfg["reference_channel"]))
    print("TinyML input: speech channel only. Reference is stored, not mixed in.")
    print()
    info = list_input_devices()
    if not info.get("ok"):
        print("FAILED to list devices.")
        print(info.get("error"))
        print(info.get("hint") or "")
        return 1
    print(f"{'idx':>4}  {'ch':>3}  {'2ch':>4}  {'rate':>8}  name")
    for d in info["devices"]:
        mark = "YES" if d["two_channel_ok"] else "no"
        print(f"{d['index']:4d}  {d['max_input_channels']:3d}  {mark:>4}  {d['default_samplerate']:8.0f}  {d['name']}")
    print()
    selected = args.device if args.device is not None else info.get("selected_device_index")
    if args.device is not None:
        save_channel_config(int(cfg["speech_channel"]), int(cfg["reference_channel"]), args.device)
        print("Saved selected device index:", args.device)
    if info["two_channel_available"]:
        print("TWO-CHANNEL INPUT: YES")
        print("Selected device index:", selected)
    else:
        print("TWO-CHANNEL INPUT: NO")
        print(info["warning"])
        print("Do not use two separate USB microphones — their clocks will drift.")
        print("A USB mic plus analog/AUX is NOT synchronized two-channel capture.")
        return 0

    if args.no_capture:
        print("(skipped live levels because you passed --no-capture)")
        return 0
    try:
        from capture import record_stereo_seconds

        print("Recording 1 second to measure levels… speak into the SPEECH mic.")
        clip = record_stereo_seconds(1.0, selected)
        print(f"Channel 1 SPEECH     RMS={clip['rms_speech']:.4f}")
        print(f"Channel 2 REFERENCE  RMS={clip['rms_reference']:.4f}")
        if clip["rms_speech"] < 1e-4 and clip["rms_reference"] < 1e-4:
            print("Both channels are nearly silent. Check cables and mic permission.")
    except Exception as exc:  # noqa: BLE001
        print("Level check skipped:", exc)
        print("Listing devices succeeded. Capture needs a real 2-in USB interface.")
    print()
    print(json.dumps({"two_channel_available": True, "selected": selected}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
