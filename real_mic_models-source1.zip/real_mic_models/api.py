"""Record real-mic speech/noise, mix, train, live-clean — two synchronized channels.

TinyML still cleans the SPEECH channel only.
The REFERENCE channel is captured, stored, and shown, but not mixed into TinyML.
"""

from __future__ import annotations

import json
import subprocess
import sys
import time
from pathlib import Path

from typing import Optional

import numpy as np
from fastapi import FastAPI, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from audio_io import list_wavs, write_wav
from config import (
    CLIP_SECONDS,
    DUAL_SYNC_DIR,
    FRONTEND,
    NOISE_DIR,
    PAIRS_DIR,
    SAMPLE_RATE,
    SPEECH_DIR,
    channel_config,
    ensure_data_dirs,
    save_channel_config,
)
from devices import list_input_devices
from dual_record import dual_counts, save_synchronized
from enhance import RealMicEnhancer
from infer import TinyInfer
from live_processor import TwoMicProcessor
from mix_dataset import build_dataset
from pairs import list_pairs, save_pair, save_pair_two_mic
from paths import MANIFEST, META_JSON

ROOT = Path(__file__).resolve().parent
ensure_data_dirs()
app = FastAPI(title="AEGIS real-mic TinyML (two microphone)")
app.mount("/static", StaticFiles(directory=str(FRONTEND)), name="static")
PAIRS_DIR.mkdir(parents=True, exist_ok=True)
DUAL_SYNC_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/pairs", StaticFiles(directory=str(PAIRS_DIR)), name="pairs")
app.mount("/dual", StaticFiles(directory=str(DUAL_SYNC_DIR)), name="dual")

_status = {"busy": False, "log": "idle"}


class PcmIn(BaseModel):
    pcm: list[float]


class StereoPcmIn(BaseModel):
    speech: list[float]
    reference: list[float]
    device_label: Optional[str] = None
    channel_count: int = 2
    capture_sample_rate: Optional[int] = None
    kind: str = "speech"


class ChannelCfgIn(BaseModel):
    speech_channel: int = Field(ge=0, le=1)
    reference_channel: int = Field(ge=0, le=1)
    audio_device_index: Optional[int] = None


def _counts() -> dict:
    inf = TinyInfer().status()
    dual = dual_counts()
    return {
        "speech": len(list_wavs(SPEECH_DIR)),
        "noise": len(list_wavs(NOISE_DIR)),
        "mixed": json.loads(MANIFEST.read_text())["clips"] if MANIFEST.exists() else 0,
        "pairs": len(list_pairs()),
        "pair_list": list_pairs()[-20:],
        "trained": META_JSON.exists(),
        "model": json.loads(META_JSON.read_text()) if META_JSON.exists() else None,
        "infer": inf,
        "busy": _status["busy"],
        "log": _status["log"],
        "clip_seconds": CLIP_SECONDS,
        "sr": SAMPLE_RATE,
        "channel_config": channel_config(),
        "path_a": "REAL microphone recordings + SOFTWARE ADDITIVE MIXING",
        "path_b": "REAL synchronized two-microphone recordings",
        "tiny_ml_input": "speech_channel_only",
        **dual,
    }


@app.get("/")
def index():
    return FileResponse(FRONTEND / "index.html")


@app.get("/api/status")
def status():
    return _counts()


@app.get("/api/devices")
def devices():
    """PortAudio devices seen by Python (Pi / Windows diagnostics). Browser devices are listed in the page."""
    return list_input_devices()


@app.get("/api/config")
def get_config():
    return channel_config()


@app.post("/api/config")
def set_config(body: ChannelCfgIn):
    try:
        cfg = save_channel_config(body.speech_channel, body.reference_channel, body.audio_device_index)
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True, "config": cfg}


@app.post("/api/record/{kind}")
async def record(kind: str, body: PcmIn):
    """Path A helper: save a mono clip into data/speech or data/noise."""
    if kind not in ("speech", "noise"):
        return {"ok": False, "error": "kind must be speech or noise"}
    pcm = np.asarray(body.pcm, dtype=np.float32)
    if pcm.size < SAMPLE_RATE:
        return {"ok": False, "error": "clip too short"}
    folder = SPEECH_DIR if kind == "speech" else NOISE_DIR
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / f"{kind}_{int(time.time() * 1000)}.wav"
    write_wav(path, pcm, SAMPLE_RATE)
    return {"ok": True, "path": path.name, "path_label": "PATH A (mono or extracted speech channel)", **_counts()}


@app.post("/api/record_stereo")
def record_stereo(body: StereoPcmIn):
    """Path B: synchronized two-channel clip. Rejects if either channel is missing."""
    if body.channel_count < 2:
        return {
            "ok": False,
            "error": "Fewer than 2 input channels. Connect both microphones to the same multi-channel USB audio interface.",
        }
    speech = np.asarray(body.speech, dtype=np.float32).reshape(-1)
    reference = np.asarray(body.reference, dtype=np.float32).reshape(-1)
    if min(len(speech), len(reference)) < SAMPLE_RATE:
        return {"ok": False, "error": "clip too short"}
    kind = body.kind if body.kind in ("speech", "noise", "live") else "speech"
    try:
        meta = save_synchronized(
            speech,
            reference,
            kind=kind,
            device_label=body.device_label,
            capture_sample_rate=body.capture_sample_rate,
        )
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True, "clip": meta, **_counts()}


@app.get("/api/pairs")
def pairs():
    return {"ok": True, "pairs": list_pairs()}


@app.post("/api/pair")
def pair_from_clip(body: PcmIn):
    pcm = np.asarray(body.pcm, dtype=np.float32)
    if pcm.size < SAMPLE_RATE:
        return {"ok": False, "error": "clip too short"}
    enh = RealMicEnhancer()
    raw, clean = enh.process_full(pcm)
    try:
        row = save_pair(raw, clean, source="record")
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True, "pair": row, **_counts()}


@app.post("/api/pair_stereo")
def pair_from_stereo(body: StereoPcmIn):
    if body.channel_count < 2:
        return {
            "ok": False,
            "error": "Fewer than 2 input channels. Connect both microphones to the same multi-channel USB audio interface.",
        }
    proc = TwoMicProcessor()
    result = proc.process_full_stereo(
        np.asarray(body.speech, dtype=np.float32),
        np.asarray(body.reference, dtype=np.float32),
    )
    try:
        row = save_pair_two_mic(result["speech_raw"], result["reference_raw"], result["speech_clean"], source="record")
    except ValueError as exc:
        return {"ok": False, "error": str(exc)}
    return {"ok": True, "pair": row, "ml": result["ml"], **_counts()}


@app.post("/api/mix")
def mix(n_clips: int = Query(240, ge=16, le=2000)):
    if _status["busy"]:
        return {"ok": False, "error": "busy"}
    try:
        meta = build_dataset(n_clips=n_clips)
        _status["log"] = f"PATH A mixed {meta['clips']} clips (software additive mixing)"
        return {"ok": True, **meta, **_counts()}
    except SystemExit as exc:
        return {"ok": False, "error": str(exc)}


@app.post("/api/train")
def train():
    if _status["busy"]:
        return {"ok": False, "error": "busy"}
    _status["busy"] = True
    _status["log"] = "training…"
    try:
        proc = subprocess.run(
            [sys.executable, str(ROOT / "train.py")],
            cwd=str(ROOT),
            capture_output=True,
            text=True,
            timeout=600,
        )
        _status["log"] = (proc.stdout or "")[-1500:] + (("\n" + proc.stderr) if proc.stderr else "")
        if proc.returncode != 0:
            return {"ok": False, "error": _status["log"], **_counts()}
        return {"ok": True, "log": _status["log"], **_counts()}
    finally:
        _status["busy"] = False


@app.websocket("/ws/live")
async def ws_live(ws: WebSocket):
    """Binary frames: interleaved float32 stereo [s0, r0, s1, r1, ...] already remapped
    so even samples are speech and odd samples are reference.
    """
    await ws.accept()
    proc = TwoMicProcessor()
    raw_s: list[np.ndarray] = []
    raw_r: list[np.ndarray] = []
    clean_s: list[np.ndarray] = []
    await ws.send_json({"type": "ready", **proc.speech.tiny.status(), "channels": 2, "tiny_ml_input": "speech_channel_only"})

    def flush_pair(source: str):
        if not raw_s:
            return None
        speech = np.concatenate(raw_s)
        reference = np.concatenate(raw_r) if raw_r else np.zeros_like(speech)
        clean = np.concatenate(clean_s)
        raw_s.clear()
        raw_r.clear()
        clean_s.clear()
        try:
            return save_pair_two_mic(speech, reference, clean, source=source)
        except ValueError:
            return None

    try:
        while True:
            msg = await ws.receive()
            if msg["type"] == "websocket.disconnect":
                flush_pair("live")
                break
            data = msg.get("bytes")
            if not data:
                text = msg.get("text")
                if text == "save":
                    row = flush_pair("live")
                    await ws.send_json({"type": "saved", "pair": row})
                continue
            pcm = np.frombuffer(data, dtype=np.float32)
            hops = proc.process_stereo_block(pcm)
            if hops:
                for h in hops:
                    raw_s.append(np.asarray(h["speech_raw"], dtype=np.float32))
                    raw_r.append(np.asarray(h["reference_raw"], dtype=np.float32))
                    clean_s.append(np.asarray(h["speech_clean"], dtype=np.float32))
                await ws.send_json({"type": "hops", "hops": hops})
    except WebSocketDisconnect:
        flush_pair("live")
        return
