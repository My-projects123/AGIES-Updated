# Real-mic TinyML (two microphones)

Train AEGIS **TinyMaskNet** (32-band GRU + VAD → ONNX INT8) on **your microphones**, then run a **first-stage** cleaner on Raspberry Pi 5.

This folder is separate from `sih26052_poc` (AEGIS-COM). That POC still uses **SIMULATED** talkers for `tiny_mask.*`. This project writes **`models/real_mic.*` only** and does not overwrite the simulated weights.

## What this stage is

```
SPEECH mic  ─┐
             ├─ same USB audio interface ─► Pi 5 ─► TinyML on speech channel ─► cleaned speech
REFERENCE mic┘                                      reference channel saved (future LMS)
```

**Not in this stage:** DCCRN, laptop second stage, LMS, wireless, Bluetooth, S2, analog ANC.

TinyML input is the **speech channel only**. The reference channel is captured and stored. The two mics are **never averaged**.

## Honest labels

| What | Label |
|---|---|
| Two-mic WAV in `data/dual_mic/synchronized/` | **REAL** synchronized recording |
| `data/speech/` and `data/noise/` | **REAL** mic (often one channel) |
| `data/mixed/` | **MIXED** — Path A software additive mix |
| Live meters / cleaned audio | **REAL** processing of the live mics |
| SIH 15 dB / 0.85 / 2.5 | **TARGET** until measured |
| Numbers in `models/real_mic.meta.json` → `eval` | **MEASURED** on the current mix set |
| Original AEGIS-COM TinyML | **SIMULATED** talkers (other folder) |

## 7-step website

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Pi/macOS: source .venv/bin/activate
pip install -r requirements.txt
python serve.py
```

Open **http://127.0.0.1:8090**

1. Select the USB audio interface (not the laptop’s built-in mic).
2. Test two meters: Channel 1 SPEECH, Channel 2 REFERENCE.
3. Record synchronized two-channel speech.
4. Build Path A dataset (software mix).
5. Train TinyML.
6. Confirm INT8/FP32, size, VAD.
7. Live test: raw speech, reference, cleaned speech.

## Commands (no website)

```bash
python audio_device_test.py --no-capture
python audio_device_test.py --device 2
python two_mic_test.py --seconds 2 --device 2
python mix_dataset.py
python train.py
python evaluate.py
python live_two_mic.py --seconds 6
python -m pytest
python pi_alsa_test.py    # lists ALSA if you are on Linux; skip on Mac/Windows
```

Copy **`real_mic_models-source.zip` only after it is rebuilt from this folder**. An older zip still contains the single-mic `np.mean` reader — do not use that archive.

## Channel map

Edit `config.py` or the website dropdown:

```
SPEECH_CHANNEL = 0
REFERENCE_CHANNEL = 1
```

Swap those two numbers if the cables are reversed. Do not put brand names in code.

## Docs for beginners

- [Windows](docs/windows_beginner.md)
- [Raspberry Pi 5](docs/raspberry_pi5.md)
- [Two-mic setup](docs/two_mic_setup.md)
- [Dataset & training](docs/dataset_training.md)
- [Troubleshooting](docs/troubleshooting.md)
- [Implementation status](docs/IMPLEMENTATION_STATUS.md)

## Copy weights into the SIH website (optional)

Only if you want the simulated-data dashboard to use **this** net:

```bash
cp models/real_mic.int8.onnx ../sih26052_poc/ml/models/tiny_mask.int8.onnx
```

That is a deliberate copy. This project never overwrites `tiny_mask.*` by itself.
