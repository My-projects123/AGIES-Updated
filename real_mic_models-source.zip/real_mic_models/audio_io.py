"""Load / save 16 kHz mono float WAVs."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import soundfile as sf
from scipy.signal import resample_poly

from config import SAMPLE_RATE


def to_mono_16k(x: np.ndarray, sr: int) -> np.ndarray:
    x = np.asarray(x, dtype=np.float64)
    if x.ndim > 1:
        x = np.mean(x, axis=-1)
    if sr != SAMPLE_RATE:
        g = np.gcd(sr, SAMPLE_RATE)
        x = resample_poly(x, SAMPLE_RATE // g, sr // g)
    return np.clip(x, -1.0, 1.0).astype(np.float32)


def read_wav(path: Path) -> np.ndarray:
    x, sr = sf.read(str(path), always_2d=False)
    return to_mono_16k(x, int(sr))


def write_wav(path: Path, x: np.ndarray, sr: int = SAMPLE_RATE) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    sf.write(str(path), np.clip(np.asarray(x, dtype=np.float64), -1.0, 1.0), sr, subtype="PCM_16")


def list_wavs(folder: Path) -> list[Path]:
    if not folder.exists():
        return []
    return sorted(p for p in folder.iterdir() if p.suffix.lower() in {".wav", ".flac"})
