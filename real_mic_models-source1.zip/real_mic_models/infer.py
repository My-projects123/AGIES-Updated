"""ONNX Runtime hop inference for the real-mic TinyML net."""

from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np

from config import HIDDEN, N_FFT, WIN_LENGTH
from fbanks import filterbank, to_bands, upsample_gain
from paths import FP32_ONNX, INT8_ONNX, META_JSON


class TinyInfer:
    def __init__(self) -> None:
        self.ok = False
        self.sess = None
        self.hidden = HIDDEN
        self.fb = filterbank()
        self.win = np.hanning(WIN_LENGTH)
        self.h = np.zeros((1, 1, self.hidden), dtype=np.float32)
        self.last_vad: float | None = None
        self._infer_s = 0.0
        self._infer_n = 0
        self.meta: dict = {}
        self.backend = "none"
        self.quantized = False
        path = INT8_ONNX if INT8_ONNX.exists() else FP32_ONNX
        if not path.exists():
            return
        try:
            import onnxruntime as ort

            self.sess = ort.InferenceSession(str(path), providers=["CPUExecutionProvider"])
            self.ok = True
            self.quantized = path == INT8_ONNX
            self.backend = "onnxruntime"
            if META_JSON.exists():
                self.meta = json.loads(META_JSON.read_text())
                self.hidden = int(self.meta.get("hidden") or HIDDEN)
                self.h = np.zeros((1, 1, self.hidden), dtype=np.float32)
        except Exception as exc:  # noqa: BLE001
            self.meta = {"error": str(exc)}

    def reset(self) -> None:
        self.h = np.zeros((1, 1, self.hidden), dtype=np.float32)
        self.last_vad = None

    def mask_frame(self, frame: np.ndarray) -> tuple[np.ndarray | None, float | None]:
        if not self.ok:
            return None, None
        x = np.asarray(frame, dtype=np.float64)
        if len(x) != WIN_LENGTH:
            x = np.pad(x, (0, max(0, WIN_LENGTH - len(x))))[:WIN_LENGTH]
        spec = np.fft.rfft(x * self.win, n=N_FFT)
        mag = np.clip(np.abs(spec), 1e-12, 1e6)
        bands = to_bands(mag.astype(np.float32), self.fb)
        logb = np.log(bands + 1e-8).reshape(1, 1, -1).astype(np.float32)
        t0 = time.perf_counter()
        gain, vad_out, h_out = self.sess.run(["gain", "vad", "h_out"], {"bands": logb, "h": self.h})
        self._infer_s += time.perf_counter() - t0
        self._infer_n += 1
        self.h = np.asarray(h_out, dtype=np.float32)
        vad = float(np.asarray(vad_out).reshape(-1)[0])
        self.last_vad = vad
        g = upsample_gain(np.asarray(gain).reshape(-1))
        if len(g) != len(mag):
            g = np.interp(np.linspace(0, 1, len(mag)), np.linspace(0, 1, len(g)), g)
        return np.clip(g, 0.0, 1.0), vad

    def status(self) -> dict:
        hop_ms = None
        if self._infer_n:
            hop_ms = round(1000.0 * self._infer_s / self._infer_n, 3)
        return {
            "available": self.ok,
            "backend": self.backend,
            "quantized": self.quantized,
            "params": self.meta.get("params"),
            "size_kb": self.meta.get("size_kb"),
            "vad_accuracy": self.meta.get("vad_accuracy"),
            "eval": self.meta.get("eval"),
            "losses": self.meta.get("losses"),
            "train_data": self.meta.get("train_data", "not trained yet"),
            "infer_ms_per_hop": hop_ms,
            "heads": self.meta.get("heads"),
            "onnx_file": None if not self.ok else ("real_mic.int8.onnx" if self.quantized else "real_mic.onnx"),
            "tiny_ml_input": "speech_channel_only",
        }
