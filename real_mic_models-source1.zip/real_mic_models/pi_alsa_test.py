#!/usr/bin/env python3
"""List ALSA capture devices (Raspberry Pi / Linux). Brand-agnostic.

    python pi_alsa_test.py

This only *lists* what Linux reports. It does NOT prove Raspberry Pi hardware
was tested. On macOS/Windows it will say arecord is missing and stop.

A USB microphone plus the Pi analog/AUX jack is NOT synchronized 2-channel capture.
Both mics should share one multi-channel USB audio interface.
"""

from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main() -> int:
    print("AEGIS ALSA diagnostic (software listing only)")
    print("Raspberry Pi hardware compatibility is NOT claimed by this script.")
    print()
    arecord = shutil.which("arecord")
    if not arecord:
        print("arecord not found. This machine is not showing Linux ALSA tools.")
        print("On Raspberry Pi OS run:  sudo apt install alsa-utils")
        print("Then:  python pi_alsa_test.py")
        return 0
    print("=== arecord -l  (capture cards) ===")
    r = subprocess.run([arecord, "-l"], capture_output=True, text=True)
    print(r.stdout or r.stderr or "(no output)")
    print("=== arecord -L  (PCM names) ===")
    r2 = subprocess.run([arecord, "-L"], capture_output=True, text=True)
    lines = [ln for ln in (r2.stdout or "").splitlines() if ln.strip()]
    for ln in lines[:80]:
        print(ln)
    if len(lines) > 80:
        print("…")
    print()
    print("Look for a device with 2 capture channels. Names come from the kernel.")
    print("Do not assume USB / AUX / a microphone brand.")
    print("Next: python audio_device_test.py --no-capture")
    print("Then: python two_mic_test.py --device <index>")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
