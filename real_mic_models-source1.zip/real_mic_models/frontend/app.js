const $ = (id) => document.getElementById(id);
const SR = 16000;
let clipSeconds = 4;
let recState = { running: false, ws: null, play: null };
let testState = { running: false, stream: null, cap: null };
let selectedDeviceId = "";
let chSpeech = 0;
let chRef = 1;

async function refresh() {
  const st = await (await fetch("/api/status")).json();
  clipSeconds = st.clip_seconds || 4;
  $("nSpeech").textContent = st.speech;
  $("nNoise").textContent = st.noise;
  $("nDual").textContent = st.synchronized || 0;
  $("nMixed").textContent = st.mixed;
  $("nModel").textContent = st.trained ? "ONNX ready" : "not trained";
  const inf = st.infer || {};
  const ev = inf.eval || (st.model && st.model.eval);
  let line = inf.available
    ? `Loaded ${inf.onnx_file || "ONNX"} · ${inf.quantized ? "INT8" : "FP32"} · ${inf.params || "?"} params · VAD acc ${inf.vad_accuracy ?? "—"} · ${inf.size_kb ?? "?"} KB`
    : "ONNX: not trained yet — complete steps 3–5. Live test still runs Wiener DSP without TinyML.";
  if (inf.infer_ms_per_hop != null) line += ` · hop ${inf.infer_ms_per_hop} ms`;
  if (ev && ev.snr_out_db != null) {
    line += ` · SNR ${ev.snr_in_db}→${ev.snr_out_db} dB (MEASURED) · STOI ${ev.stoi_out ?? "n/a"} · PESQ ${ev.pesq_out ?? "n/a"}`;
  }
  $("mlLine").textContent = line;
  const cfg = st.channel_config || {};
  chSpeech = Number(cfg.speech_channel ?? 0);
  chRef = Number(cfg.reference_channel ?? 1);
  $("chSpeech").value = String(chSpeech);
  $("chRef").value = String(chRef);
  $("channelLine").textContent =
    `Channel map: SPEECH=index ${chSpeech} · REFERENCE=index ${chRef} · TinyML input = speech channel only`;
  $("modelBox").textContent = inf.available
    ? `Model loaded: YES\nFile: ${inf.onnx_file}\nType: ${inf.quantized ? "INT8" : "FP32"}\nParams: ${inf.params}\nSize: ${inf.size_kb} KB\nVAD accuracy: ${inf.vad_accuracy ?? "—"}\nInference: ${inf.infer_ms_per_hop ?? "run live to measure"} ms/hop\nTinyML input: speech channel only (shape 1×1×32 bands)`
    : "Model loaded: NO — train at step 5. Live mode will still run the Wiener gate (DSP fallback).";
  if (st.log) $("trainLog").textContent = st.log;
  renderPairs(st.pair_list || []);
  return st;
}

function renderPairs(rows) {
  const box = $("pairList");
  if (!rows.length) {
    box.innerHTML = '<p class="hint">No pairs yet.</p>';
    return;
  }
  box.innerHTML = rows.slice().reverse().map((p) => `
    <div class="pair-row">
      <div>
        <p class="lbl">${p.id}</p>
        <p class="hint">${p.seconds}s · ${p.source} · ${p.channels || 1}ch</p>
      </div>
      <div><p class="lbl">Raw speech</p><audio controls src="${p.raw_url}"></audio></div>
      <div><p class="lbl">Reference</p>${p.reference_url ? `<audio controls src="${p.reference_url}"></audio>` : '<p class="hint">n/a</p>'}</div>
      <div><p class="lbl">Cleaned speech</p><audio controls src="${p.clean_url}"></audio></div>
    </div>`).join("");
}

function resampleLinear(input, fromRate, toRate) {
  if (fromRate === toRate) return input;
  const ratio = fromRate / toRate;
  const n = Math.max(1, Math.floor(input.length / ratio));
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const x = i * ratio;
    const i0 = Math.floor(x);
    const f = x - i0;
    out[i] = (input[i0] || 0) * (1 - f) + (input[i0 + 1] || input[i0] || 0) * f;
  }
  return out;
}

function rms(buf) {
  let s = 0;
  for (let i = 0; i < buf.length; i++) s += buf[i] * buf[i];
  return Math.sqrt(s / Math.max(buf.length, 1));
}

function setMeter(fillId, rmsId, value) {
  const pct = Math.min(100, Math.round(value * 400));
  $(fillId).style.width = `${pct}%`;
  $(rmsId).textContent = `level ${value.toFixed(4)} RMS`;
}

function audioConstraints(minCh) {
  const audio = {
    echoCancellation: false,
    noiseSuppression: false,
    autoGainControl: false,
    channelCount: minCh >= 2 ? { ideal: 2, min: 2 } : { ideal: 1 },
  };
  if (selectedDeviceId) audio.deviceId = { exact: selectedDeviceId };
  return { audio };
}

async function openMic(minCh) {
  try {
    return await navigator.mediaDevices.getUserMedia(audioConstraints(minCh));
  } catch (err) {
    if (minCh >= 2) {
      throw new Error(
        "Could not open a 2-channel input. Connect both microphones to the same multi-channel USB audio interface. (" + err.message + ")"
      );
    }
    throw err;
  }
}

function streamInfo(stream, ctx) {
  const track = stream.getAudioTracks()[0];
  const settings = track ? track.getSettings() : {};
  return {
    channels: settings.channelCount || ctx.destination.channelCount || 1,
    sampleRate: settings.sampleRate || ctx.sampleRate,
    device: settings.deviceId || selectedDeviceId || "(default)",
    label: track ? track.label : "",
  };
}

async function listBrowserDevices() {
  $("deviceStat").textContent = "asking microphone permission…";
  const tmp = await navigator.mediaDevices.getUserMedia({ audio: true });
  tmp.getTracks().forEach((t) => t.stop());
  const all = await navigator.mediaDevices.enumerateDevices();
  const inputs = all.filter((d) => d.kind === "audioinput");
  const sel = $("deviceSel");
  sel.innerHTML = inputs.map((d) =>
    `<option value="${d.deviceId}">${d.label || "(unnamed microphone)"}</option>`
  ).join("") || '<option value="">no input devices</option>';
  if (inputs[0]) {
    selectedDeviceId = inputs[0].deviceId;
    sel.value = selectedDeviceId;
  }
  $("deviceStat").textContent = `${inputs.length} input device(s). Pick the USB audio interface, not a built-in laptop mic.`;
  try {
    const py = await (await fetch("/api/devices")).json();
    $("pyDevices").textContent = py.ok
      ? py.devices.map((d) =>
        `#${d.index}  ${d.max_input_channels}ch  ${d.two_channel_ok ? "2ch-OK" : "mono"}  ${d.name}`
      ).join("\n") + (py.two_channel_available ? "\n\nPython: TWO-CHANNEL INPUT YES" : "\n\nPython: TWO-CHANNEL INPUT NO\n" + (py.warning || ""))
      : (py.error || "Python device list failed") + "\n" + (py.hint || "");
  } catch (e) {
    $("pyDevices").textContent = "Python device list unavailable (is serve.py running?)";
  }
}

$("deviceSel").addEventListener("change", () => {
  selectedDeviceId = $("deviceSel").value;
});
$("btnDevices").addEventListener("click", () => listBrowserDevices().catch((e) => { $("deviceStat").textContent = e.message; }));

$("btnSaveCh").addEventListener("click", async () => {
  const speech_channel = Number($("chSpeech").value);
  const reference_channel = Number($("chRef").value);
  const j = await (await fetch("/api/config", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ speech_channel, reference_channel }),
  })).json();
  $("testStat").textContent = j.ok ? "channel map saved" : j.error;
  await refresh();
});

function remap(ch0, ch1) {
  return chSpeech === 0 ? [ch0, ch1] : [ch1, ch0];
}

async function startLevelTest() {
  const stream = await openMic(2);
  const cap = new AudioContext();
  const info = streamInfo(stream, cap);
  if ((info.channels || 1) < 2) {
    stream.getTracks().forEach((t) => t.stop());
    cap.close();
    throw new Error("Connect both microphones to the same multi-channel USB audio interface. (browser opened fewer than 2 channels)");
  }
  $("testMeta").textContent = `sample rate ${info.sampleRate} · channels ${info.channels} · device ${info.label || info.device} · assignment SPEECH=${chSpeech} REFERENCE=${chRef} · duration live`;
  const src = cap.createMediaStreamSource(stream);
  const node = cap.createScriptProcessor(2048, 2, 2);
  node.onaudioprocess = (ev) => {
    const a = ev.inputBuffer.getChannelData(0);
    const b = ev.inputBuffer.numberOfChannels > 1 ? ev.inputBuffer.getChannelData(1) : a;
    const [sp, rf] = remap(a, b);
    setMeter("mSpeech", "rmsSpeech", rms(sp));
    setMeter("mRef", "rmsRef", rms(rf));
  };
  const mute = cap.createGain();
  mute.gain.value = 0;
  src.connect(node);
  node.connect(mute);
  mute.connect(cap.destination);
  testState = { running: true, stream, cap, node, src };
  $("btnTest").disabled = true;
  $("btnTestStop").disabled = false;
  $("testStat").textContent = "listening — speak into SPEECH, keep REFERENCE in the room";
}

function stopLevelTest() {
  try { testState.node && testState.node.disconnect(); } catch (e) {}
  try { testState.src && testState.src.disconnect(); } catch (e) {}
  try { testState.cap && testState.cap.close(); } catch (e) {}
  if (testState.stream) testState.stream.getTracks().forEach((t) => t.stop());
  testState = { running: false };
  $("btnTest").disabled = false;
  $("btnTestStop").disabled = true;
  $("testStat").textContent = "test stopped";
}

$("btnTest").addEventListener("click", () => startLevelTest().catch((e) => { $("testStat").textContent = e.message; }));
$("btnTestStop").addEventListener("click", stopLevelTest);

async function captureStereo(seconds, statusEl) {
  statusEl.textContent = "allow mic…";
  const stream = await openMic(2);
  const ctx = new AudioContext();
  const info = streamInfo(stream, ctx);
  const nCh = info.channels || ctx.createMediaStreamSource(stream).channelCount || 1;
  if (nCh < 2 && (stream.getAudioTracks()[0].getSettings().channelCount || 1) < 2) {
    // Still try 2-in processor; reject if buffer is mono.
  }
  const capRate = ctx.sampleRate;
  const src = ctx.createMediaStreamSource(stream);
  const node = ctx.createScriptProcessor(4096, 2, 2);
  const ch0 = [];
  const ch1 = [];
  const need = Math.ceil(capRate * seconds);
  let n = 0;
  const meta = streamInfo(stream, ctx);
  $("testMeta").textContent = `sample rate ${meta.sampleRate} · channels ${meta.channels} · device ${meta.label || meta.device} · assignment SPEECH=${chSpeech} REFERENCE=${chRef} · duration ${seconds}s`;
  await new Promise((resolve, reject) => {
    node.onaudioprocess = (ev) => {
      if (ev.inputBuffer.numberOfChannels < 2) {
        node.disconnect();
        src.disconnect();
        stream.getTracks().forEach((t) => t.stop());
        ctx.close();
        reject(new Error("Connect both microphones to the same multi-channel USB audio interface. (got 1 channel)"));
        return;
      }
      const a = ev.inputBuffer.getChannelData(0);
      const b = ev.inputBuffer.getChannelData(1);
      ch0.push(new Float32Array(a));
      ch1.push(new Float32Array(b));
      n += a.length;
      statusEl.textContent = `recording… ${(n / capRate).toFixed(1)}s · ${meta.channels}ch`;
      if (n >= need) {
        node.disconnect();
        src.disconnect();
        stream.getTracks().forEach((t) => t.stop());
        ctx.close();
        resolve();
      }
    };
    const mute = ctx.createGain();
    mute.gain.value = 0;
    src.connect(node);
    node.connect(mute);
    mute.connect(ctx.destination);
  });
  const join = (chunks) => {
    const out = new Float32Array(n);
    let o = 0;
    for (const c of chunks) { out.set(c, o); o += c.length; }
    return resampleLinear(out.subarray(0, need), capRate, SR);
  };
  const [speech, reference] = remap(join(ch0), join(ch1));
  return {
    speech: Array.from(speech),
    reference: Array.from(reference),
    device_label: meta.label || meta.device,
    channel_count: 2,
    capture_sample_rate: capRate,
  };
}

async function captureMono(seconds, statusEl) {
  statusEl.textContent = "allow mic…";
  const stream = await openMic(1);
  const ctx = new AudioContext();
  const capRate = ctx.sampleRate;
  const src = ctx.createMediaStreamSource(stream);
  const node = ctx.createScriptProcessor(4096, 1, 1);
  const chunks = [];
  const need = Math.ceil(capRate * seconds);
  let n = 0;
  await new Promise((resolve) => {
    node.onaudioprocess = (ev) => {
      const pcm = ev.inputBuffer.getChannelData(0);
      chunks.push(new Float32Array(pcm));
      n += pcm.length;
      statusEl.textContent = `recording… ${(n / capRate).toFixed(1)}s`;
      if (n >= need) {
        node.disconnect();
        src.disconnect();
        stream.getTracks().forEach((t) => t.stop());
        ctx.close();
        resolve();
      }
    };
    const mute = ctx.createGain();
    mute.gain.value = 0;
    src.connect(node);
    node.connect(mute);
    mute.connect(ctx.destination);
  });
  const joined = new Float32Array(n);
  let o = 0;
  for (const c of chunks) { joined.set(c, o); o += c.length; }
  return Array.from(resampleLinear(joined.subarray(0, need), capRate, SR));
}

async function recordKind(kind) {
  const el = kind === "speech" ? $("speechStat") : $("noiseStat");
  const btn = kind === "speech" ? $("btnSpeech") : $("btnNoise");
  btn.disabled = true;
  try {
    const pcm = await captureMono(clipSeconds, el);
    const res = await fetch(`/api/record/${kind}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pcm }),
    });
    const j = await res.json();
    el.textContent = j.ok ? `saved ${j.path} (Path A)` : j.error;
    await refresh();
  } catch (err) {
    el.textContent = err.message;
  }
  btn.disabled = false;
}

async function recordDual(kind) {
  const el = kind === "speech" ? $("dualSpeechStat") : $("dualNoiseStat");
  const btn = kind === "speech" ? $("btnDualSpeech") : $("btnDualNoise");
  btn.disabled = true;
  try {
    const body = await captureStereo(clipSeconds, el);
    body.kind = kind;
    const j = await (await fetch("/api/record_stereo", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    })).json();
    el.textContent = j.ok ? `saved ${j.clip.id} (${j.clip.duration_seconds}s, 2ch, Path B)` : j.error;
    await refresh();
  } catch (err) {
    el.textContent = err.message;
  }
  btn.disabled = false;
}

$("btnSpeech").addEventListener("click", () => recordKind("speech"));
$("btnNoise").addEventListener("click", () => recordKind("noise"));
$("btnDualSpeech").addEventListener("click", () => recordDual("speech"));
$("btnDualNoise").addEventListener("click", () => recordDual("noise"));

$("btnMix").addEventListener("click", async () => {
  $("trainLog").textContent = "PATH A mixing (software additive — not a field recording)…";
  const j = await (await fetch("/api/mix", { method: "POST" })).json();
  $("trainLog").textContent = j.ok
    ? `PATH A mixed ${j.clips} clips from ${j.speech_files} speech + ${j.noise_files} noise — ${j.source}`
    : j.error;
  await refresh();
});

$("btnTrain").addEventListener("click", async () => {
  $("trainLog").textContent = "training on CPU — this can take a minute…";
  $("btnTrain").disabled = true;
  try {
    const j = await (await fetch("/api/train", { method: "POST" })).json();
    $("trainLog").textContent = j.log || j.error || JSON.stringify(j);
    await refresh();
  } catch (err) {
    $("trainLog").textContent = err.message;
  }
  $("btnTrain").disabled = false;
});

function draw(id, hop, color) {
  const c = $(id);
  const w = c.clientWidth || 400;
  const h = 88;
  if (c.width !== w * 2) {
    c.width = w * 2;
    c.height = h * 2;
  }
  const ctx = c.getContext("2d");
  ctx.setTransform(2, 0, 0, 2, 0, 0);
  ctx.fillStyle = "#243826";
  ctx.fillRect(0, 0, w, h);
  ctx.strokeStyle = color;
  ctx.beginPath();
  for (let x = 0; x < w; x++) {
    const s = hop[Math.floor((x / w) * hop.length)] || 0;
    const y = h / 2 - s * h * 0.42;
    if (x === 0) ctx.moveTo(x, y);
    else ctx.lineTo(x, y);
  }
  ctx.stroke();
}

function playHop(pcm) {
  if (!recState.play) return;
  const ctx = recState.play;
  let data = pcm;
  if (Math.abs(ctx.sampleRate - SR) > 50) data = resampleLinear(pcm, SR, ctx.sampleRate);
  const buf = ctx.createBuffer(1, data.length, ctx.sampleRate);
  buf.getChannelData(0).set(data);
  const src = ctx.createBufferSource();
  src.buffer = buf;
  src.connect(ctx.destination);
  const now = ctx.currentTime;
  if (recState.nextT < now + 0.03) recState.nextT = now + 0.03;
  src.start(recState.nextT);
  recState.nextT += data.length / ctx.sampleRate;
}

function interleave(speech, reference) {
  const n = Math.min(speech.length, reference.length);
  const out = new Float32Array(n * 2);
  for (let i = 0; i < n; i++) {
    out[i * 2] = speech[i];
    out[i * 2 + 1] = reference[i];
  }
  return out;
}

async function startLive() {
  $("liveStat").textContent = "allow mic…";
  const stream = await openMic(2);
  recState.stream = stream;
  recState.play = new AudioContext();
  recState.nextT = 0;
  await recState.play.resume();
  const cap = new AudioContext();
  const meta = streamInfo(stream, cap);
  $("testMeta").textContent = `LIVE sample rate ${meta.sampleRate} · channels ${meta.channels} · ${meta.label || meta.device}`;
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${proto}://${location.host}/ws/live`);
  ws.binaryType = "arraybuffer";
  await new Promise((res, rej) => {
    ws.onopen = res;
    ws.onerror = () => rej(new Error("websocket failed — is serve.py running?"));
  });
  recState.ws = ws;
  recState.running = true;
  const src = cap.createMediaStreamSource(stream);
  const node = cap.createScriptProcessor(2048, 2, 2);
  node.onaudioprocess = (ev) => {
    if (!recState.running || ws.readyState !== 1) return;
    if (ev.inputBuffer.numberOfChannels < 2) return;
    const a = resampleLinear(ev.inputBuffer.getChannelData(0), cap.sampleRate, SR);
    const b = resampleLinear(ev.inputBuffer.getChannelData(1), cap.sampleRate, SR);
    // Hardware order: server splits with SPEECH_CHANNEL / REFERENCE_CHANNEL.
    ws.send(interleave(a, b).buffer);
  };
  ws.onmessage = (ev) => {
    const msg = JSON.parse(ev.data);
    if (msg.type === "saved") {
      $("liveStat").textContent = msg.pair
        ? `saved ${msg.pair.id} (${msg.pair.seconds}s speech+reference+clean)`
        : "session too short to save";
      refresh();
      return;
    }
    if (msg.type !== "hops") return;
    for (const h of msg.hops) {
      draw("waveIn", h.speech_raw || h.pcm_in, "#DCE8D4");
      draw("waveRef", h.reference_raw || [], "#9aaf96");
      draw("waveOut", h.speech_clean || h.pcm, "#FFFFFF");
      $("liveGate").textContent = h.gate_open
        ? `SPEECH · open (GRU ${h.tiny_vad == null ? "n/a" : Number(h.tiny_vad).toFixed(2)})`
        : `no speech · ${Number(h.gate_db || 0).toFixed(0)} dB`;
      $("liveLat").textContent = `latency ${h.latency_ms ?? "—"} ms/hop · TinyML ${h.ml ? "ON" : "OFF (DSP only)"} · TinyML input = speech only`;
      playHop(Float32Array.from(h.speech_clean || h.pcm || []));
    }
  };
  const mute = cap.createGain();
  mute.gain.value = 0;
  src.connect(node);
  node.connect(mute);
  mute.connect(cap.destination);
  recState.cap = cap;
  recState.node = node;
  recState.src = src;
  $("btnLive").disabled = true;
  $("btnStop").disabled = false;
  $("liveStat").textContent = "LIVE 2-ch · stop to save";
}

function stopLive() {
  recState.running = false;
  try {
    if (recState.ws && recState.ws.readyState === 1) recState.ws.send("save");
  } catch (e) {}
  setTimeout(() => {
    try { recState.ws && recState.ws.close(); } catch (e) {}
    try {
      recState.node && recState.node.disconnect();
      recState.src && recState.src.disconnect();
      recState.cap && recState.cap.close();
      recState.play && recState.play.close();
    } catch (e) {}
    if (recState.stream) recState.stream.getTracks().forEach((t) => t.stop());
    $("btnLive").disabled = false;
    $("btnStop").disabled = true;
    refresh();
  }, 250);
}

$("btnPair").addEventListener("click", async () => {
  const el = $("liveStat");
  $("btnPair").disabled = true;
  try {
    const body = await captureStereo(clipSeconds, el);
    el.textContent = "cleaning speech channel + saving pair…";
    const j = await (await fetch("/api/pair_stereo", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    })).json();
    el.textContent = j.ok ? `saved ${j.pair.id} (${j.pair.seconds}s, TinyML ${j.ml ? "on" : "off"})` : (j.error || "save failed");
    await refresh();
  } catch (err) {
    el.textContent = err.message;
  }
  $("btnPair").disabled = false;
});
$("btnLive").addEventListener("click", () => startLive().catch((e) => { $("liveStat").textContent = e.message; }));
$("btnStop").addEventListener("click", stopLive);
refresh();
