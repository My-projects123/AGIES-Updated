"""TinyMaskNet shapes, ONNX inference, no-model fallback."""

from __future__ import annotations

import numpy as np
import pytest
import torch

from config import HIDDEN, N_BANDS, WIN_LENGTH
from enhance import RealMicEnhancer
from infer import TinyInfer
from live_processor import TwoMicProcessor
from model import TinyMaskNet
from paths import FP32_ONNX, INT8_ONNX


def test_tinymask_shapes():
    net = TinyMaskNet()
    bands = torch.zeros(2, 5, N_BANDS)
    gain, vad = net.forward_seq(bands)
    assert gain.shape == (2, 5, N_BANDS)
    assert vad.shape == (2, 5, 1)
    h = torch.zeros(1, 1, HIDDEN)
    g, v, h2 = net.forward(torch.zeros(1, 1, N_BANDS), h)
    assert g.shape == (1, 1, N_BANDS)
    assert v.shape == (1, 1, 1)
    assert h2.shape == (1, 1, HIDDEN)
    assert net.param_count() < 20000


def test_onnx_inference_if_present():
    tiny = TinyInfer()
    frame = (0.01 * np.random.default_rng(0).standard_normal(WIN_LENGTH)).astype(np.float32)
    gain, vad = tiny.mask_frame(frame)
    if not tiny.ok:
        assert gain is None and vad is None
        pytest.skip("No real_mic.onnx / real_mic.int8.onnx yet — train first.")
    assert gain is not None
    assert gain.ndim == 1
    assert 0.0 <= float(vad) <= 1.0
    assert tiny.status()["available"] is True
    assert tiny.status()["onnx_file"] in {"real_mic.onnx", "real_mic.int8.onnx"}


def test_int8_preferred_when_present():
    tiny = TinyInfer()
    if INT8_ONNX.exists() and tiny.ok:
        assert tiny.quantized is True
        assert tiny.status()["onnx_file"] == "real_mic.int8.onnx"
    elif FP32_ONNX.exists() and tiny.ok:
        assert tiny.quantized is False
    else:
        pytest.skip("no ONNX on disk")


def test_no_model_graceful_fallback(monkeypatch, tmp_path):
    monkeypatch.setattr("infer.INT8_ONNX", tmp_path / "missing.int8.onnx")
    monkeypatch.setattr("infer.FP32_ONNX", tmp_path / "missing.onnx")
    monkeypatch.setattr("infer.META_JSON", tmp_path / "missing.meta.json")
    tiny = TinyInfer()
    assert tiny.ok is False
    g, v = tiny.mask_frame(np.zeros(WIN_LENGTH, dtype=np.float32))
    assert g is None and v is None
    st = tiny.status()
    assert st["available"] is False


def test_live_processor_two_channel_dict():
    proc = TwoMicProcessor()
    n = WIN_LENGTH * 3
    speech = (0.05 * np.random.default_rng(1).standard_normal(n)).astype(np.float32)
    reference = (0.02 * np.random.default_rng(2).standard_normal(n)).astype(np.float32)
    out = proc.process_full_stereo(speech, reference)
    assert out["channels"] == 2
    assert out["sample_rate"] == 16000
    assert "speech_raw" in out and "reference_raw" in out and "speech_clean" in out
    assert len(out["speech_clean"]) > 0
    # Reference must not be identical to the cleaned speech.
    assert float(np.mean(np.abs(out["reference_raw"][:200] - out["speech_clean"][:200]))) >= 0.0
    hops = proc.process_stereo_block(np.stack([speech[:512], reference[:512]], axis=1))
    # may be empty if buffers already consumed; reset and try a large block
    proc.reset()
    hops = proc.process_stereo_block(np.stack([speech, reference], axis=1))
    assert hops
    h = hops[0]
    assert set(h).issuperset({"speech_raw", "reference_raw", "speech_clean", "tiny_vad", "gate_open", "latency_ms"})


def test_pcm_2ch_tinyml_speech_only_reference_preserved(monkeypatch):
    monkeypatch.setattr("audio_io.channel_config", lambda: {"speech_channel": 0, "reference_channel": 1})
    monkeypatch.setattr("live_processor.channel_config", lambda: {"speech_channel": 0, "reference_channel": 1})
    proc = TwoMicProcessor()
    n = WIN_LENGTH * 4
    speech = np.full(n, 0.11, dtype=np.float32)
    reference = np.full(n, 0.77, dtype=np.float32)
    hops = proc.process_pcm_2ch(np.stack([speech, reference], axis=1), hardware_order=True)
    assert hops
    raw = np.concatenate([np.asarray(h["speech_raw"], dtype=np.float32) for h in hops])
    ref = np.concatenate([np.asarray(h["reference_raw"], dtype=np.float32) for h in hops])
    assert float(np.mean(np.abs(raw))) < 0.3
    assert float(np.mean(np.abs(ref))) > 0.5
    # TinyML / Wiener input is the speech hop, not the loud reference.
    assert abs(float(np.mean(raw)) - 0.11) < 0.05


def test_enhancer_works_without_asserting_ml():
    enh = RealMicEnhancer()
    x = (0.03 * np.random.default_rng(3).standard_normal(1600)).astype(np.float32)
    hops = enh.process_block(x)
    assert hops
    assert "pcm" in hops[0]
