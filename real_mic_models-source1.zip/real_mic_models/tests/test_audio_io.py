"""Two-mic audio I/O tests. No USB hardware required."""

from __future__ import annotations

from pathlib import Path

import numpy as np
import pytest
import soundfile as sf

import audio_io
from audio_io import (
    interleave,
    read_wav_mono_16k,
    read_wav_stereo_16k,
    resample_to_16k,
    split_channels,
    to_mono_16k,
    write_wav,
    write_wav_stereo,
)
from config import SAMPLE_RATE


def _sine(n, freq, sr=SAMPLE_RATE):
    t = np.arange(n) / sr
    return (0.2 * np.sin(2 * np.pi * freq * t)).astype(np.float32)


def test_mono_wav_roundtrip(tmp_path: Path):
    x = _sine(SAMPLE_RATE, 440)
    p = tmp_path / "mono.wav"
    write_wav(p, x)
    y = read_wav_mono_16k(p)
    assert y.ndim == 1
    assert abs(len(y) - SAMPLE_RATE) < 8
    assert float(np.sqrt(np.mean(y ** 2))) > 0.05


def test_stereo_wav_preserves_channels(tmp_path: Path, monkeypatch):
    monkeypatch.setattr("audio_io.channel_config", lambda: {"speech_channel": 0, "reference_channel": 1})
    left = _sine(SAMPLE_RATE, 440)
    right = _sine(SAMPLE_RATE, 880)
    p = tmp_path / "stereo.wav"
    write_wav_stereo(p, left, right)
    data, sr = sf.read(str(p), always_2d=True)
    assert data.shape[1] == 2
    stereo = read_wav_stereo_16k(p)
    assert stereo.shape[1] == 2
    # Different frequencies must still be different after resample — not averaged.
    assert float(np.mean(np.abs(stereo[:, 0] - stereo[:, 1]))) > 0.02
    # Mono reader must take speech channel, not the mean of both mics.
    mono = read_wav_mono_16k(p)
    # Default speech channel is 0 = left.
    assert float(np.mean(np.abs(mono - stereo[:, 0]))) < 0.02
    mean = (stereo[:, 0] + stereo[:, 1]) / 2
    assert float(np.mean(np.abs(mono - mean))) > 0.01


def test_stereo_reader_rejects_mono(tmp_path: Path):
    p = tmp_path / "only_one.wav"
    write_wav(p, _sine(8000, 200))
    with pytest.raises(ValueError, match="2 channels"):
        read_wav_stereo_16k(p)


def test_sample_rate_conversion_stereo(tmp_path: Path):
    sr = 48000
    n = sr  # 1 second
    left = _sine(n, 300, sr)
    right = np.zeros(n, dtype=np.float32)
    right[::100] = 0.5
    p = tmp_path / "48k.wav"
    sf.write(str(p), np.stack([left, right], axis=1), sr)
    stereo = read_wav_stereo_16k(p)
    assert stereo.shape[1] == 2
    assert abs(stereo.shape[0] - SAMPLE_RATE) < 32
    # Right channel still has spikes; left is a sine — they must not be identical.
    assert float(np.max(np.abs(stereo[:, 1]))) > 0.1
    assert float(np.max(np.abs(stereo[:, 0]))) > 0.05


def test_split_and_interleave():
    s = _sine(256, 100)
    r = _sine(256, 250)
    stacked = np.stack([s, r], axis=1)
    a, b = split_channels(stacked)
    assert np.allclose(a, s)
    assert np.allclose(b, r)
    interleaved = interleave(s, r)
    a2, b2 = split_channels(interleaved)
    assert np.allclose(a2, s)
    assert np.allclose(b2, r)


def test_hardware_order_remap(tmp_path: Path, monkeypatch):
    monkeypatch.setattr("audio_io.channel_config", lambda: {"speech_channel": 1, "reference_channel": 0})
    n = SAMPLE_RATE // 4
    usb = np.stack([np.zeros(n, dtype=np.float32), _sine(n, 440)], axis=1)
    p = tmp_path / "usb.wav"
    sf.write(str(p), usb, SAMPLE_RATE)
    stereo = read_wav_stereo_16k(p, hardware_order=True)
    assert float(np.sqrt(np.mean(stereo[:, 0] ** 2))) > 0.05
    assert float(np.sqrt(np.mean(stereo[:, 1] ** 2))) < 0.01


def test_source_does_not_average_channels():
    text = Path(__file__).resolve().parents[1].joinpath("audio_io.py").read_text()
    assert "np.mean(x, axis=-1)" not in text
    assert "x = np.mean" not in text


def test_read_wav_2ch_alias(tmp_path: Path):
    from audio_io import read_wav_2ch_16k

    left = _sine(SAMPLE_RATE // 4, 440)
    right = _sine(SAMPLE_RATE // 4, 880)
    p = tmp_path / "s.wav"
    write_wav_stereo(p, left, right)
    stereo = read_wav_2ch_16k(p)
    assert stereo.shape[1] == 2
    assert float(np.mean(np.abs(stereo[:, 0] - stereo[:, 1]))) > 0.02


def test_split_pcm_2ch_uses_config(monkeypatch):
    from audio_io import split_pcm_2ch

    monkeypatch.setattr("audio_io.channel_config", lambda: {"speech_channel": 1, "reference_channel": 0})
    n = 64
    pcm = np.stack([np.zeros(n, np.float32), np.ones(n, np.float32) * 0.3], axis=1)
    speech, reference = split_pcm_2ch(pcm)
    assert float(speech.mean()) > 0.2
    assert float(reference.mean()) == 0.0


def test_to_mono_does_not_average_stereo(monkeypatch):
    monkeypatch.setattr("audio_io.channel_config", lambda: {"speech_channel": 0, "reference_channel": 1})
    x = np.stack([np.ones(100), np.zeros(100)], axis=1)
    y = to_mono_16k(x, SAMPLE_RATE)
    assert abs(float(y.mean()) - 1.0) < 1e-5
