# Dataset and training

## Path A — controlled mix (what TinyML trains on)

**Label: MIXED** (real mics + software mix)

1. Speech clips in `data/speech/` — you talking, quiet room. **REAL**.
2. Noise clips in `data/noise/` — nobody talking. **REAL**.
3. `python mix_dataset.py` writes `data/mixed/` at SNRs −5…15 dB plus reverb/clipping. **MIXED**.
4. `python train.py` fits TinyMaskNet on the **speech-channel** STFT bands.

Clean target = the quiet-room speech recording. That is why Path A exists. It is **not** a simultaneous two-mic field recording.

Two-mic “I am talking” takes also copy the speech channel into `data/speech/` so Path A can use them.

## Path B — synchronized two-mic archive

**Label: REAL**

Files:

- `data/dual_mic/synchronized/{id}_stereo.wav` — 2 channels, 16 kHz
- `{id}.json` — sample rate, channels, speech/reference indices, duration, device label
- extracted `dual_mic/speech/` and `dual_mic/reference/` — copies, not averages

The reference track is for a **future** LMS/adaptive stage. TinyML does not train on it in this stage.

## TinyML (unchanged architecture)

| Item | Value |
|---|---|
| Rate | 16 kHz |
| N_FFT / hop / win | 512 / 256 / 512 |
| Bands | 32 |
| GRU hidden | 48 |
| Parameters | ~13 425 |
| Input | log bands of **speech** hop `(1,1,32)` |
| Output | gain `(1,1,32)`, VAD `(1,1,1)`, state `(1,1,48)` |
| Files | `models/real_mic.pt`, `.onnx`, `.int8.onnx`, `.meta.json` |

Loss (training): SI-SNR + L1 + L2 + speech-weighted perceptual + VAD BCE.

Metrics after train (`evaluate.py`): SNR, SI-SNR, STOI, PESQ if installed.  
**TARGET** (not claimed): SNR 15 dB, STOI 0.85, PESQ 2.5.

## Original AEGIS-COM

`sih26052_poc/ml/models/tiny_mask.*` = **SIMULATED** talkers. This project does not delete or overwrite them.
