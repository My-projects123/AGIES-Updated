"""Evaluate a trained masker: SNR, SI-SNR, STOI, PESQ on held-out REAL-mic mixes.

    python evaluate.py

STOI needs `pystoi`. PESQ needs `pesq` (native wheel; skipped if missing).
Scores are MEASURED on the mixed validation clips, not SIH TARGET numbers.
"""

from __future__ import annotations

import json
import warnings

import numpy as np
import torch

from audio_io import read_wav
from config import HOP, MIXED_DIR, N_FFT, SAMPLE_RATE, WIN_LENGTH
from fbanks import filterbank, to_bands, upsample_gain
from model import TinyMaskNet
from paths import MANIFEST, META_JSON, WEIGHTS


def _align(a: np.ndarray, b: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    n = min(len(a), len(b))
    return np.asarray(a[:n], dtype=np.float64), np.asarray(b[:n], dtype=np.float64)


def snr_db(clean: np.ndarray, est: np.ndarray) -> float:
    s, y = _align(clean, est)
    return float(10.0 * np.log10((np.mean(s ** 2) + 1e-12) / (np.mean((y - s) ** 2) + 1e-12)))


def si_snr_db(clean: np.ndarray, est: np.ndarray) -> float:
    s, y = _align(clean, est)
    s -= np.mean(s)
    y -= np.mean(y)
    s_t = (np.dot(y, s) / (np.dot(s, s) + 1e-12)) * s
    e = y - s_t
    return float(10.0 * np.log10((np.dot(s_t, s_t) + 1e-12) / (np.dot(e, e) + 1e-12)))


def try_stoi(clean: np.ndarray, est: np.ndarray) -> dict:
    try:
        from pystoi import stoi as stoi_fn

        s, y = _align(clean, est)
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            val = float(stoi_fn(s, y, SAMPLE_RATE, extended=False))
        return {"available": True, "value": val, "label": "REAL / MEASURED"}
    except Exception as exc:  # noqa: BLE001
        return {"available": False, "value": None, "label": "UNAVAILABLE", "reason": str(exc)}


def try_pesq(clean: np.ndarray, est: np.ndarray) -> dict:
    try:
        from pesq import pesq as pesq_fn

        s, y = _align(clean, est)
        val = float(pesq_fn(SAMPLE_RATE, s, y, "wb"))
        return {"available": True, "value": val, "label": "REAL / MEASURED"}
    except Exception as exc:  # noqa: BLE001
        return {"available": False, "value": None, "label": "UNAVAILABLE / TARGET only", "reason": str(exc), "target": 2.5}


def stft_frames(x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    win = np.hanning(WIN_LENGTH)
    if len(x) < WIN_LENGTH:
        x = np.pad(x, (0, WIN_LENGTH - len(x)))
    mags, phases = [], []
    for start in range(0, len(x) - WIN_LENGTH + 1, HOP):
        spec = np.fft.rfft(x[start : start + WIN_LENGTH] * win, n=N_FFT)
        mags.append(np.abs(spec) + 1e-12)
        phases.append(np.angle(spec))
    return np.stack(mags), np.stack(phases)


def overlap_add(frames: list[np.ndarray], n_samples: int) -> np.ndarray:
    win = np.hanning(WIN_LENGTH)
    acc = np.zeros(n_samples + WIN_LENGTH)
    w2 = np.zeros(n_samples + WIN_LENGTH)
    for i, fr in enumerate(frames):
        sl = slice(i * HOP, i * HOP + WIN_LENGTH)
        acc[sl] += fr
        w2[sl] += win ** 2
    return acc[:n_samples] / np.maximum(w2[:n_samples], 0.42)


def enhance_wav(model: TinyMaskNet, fb: np.ndarray, noisy: np.ndarray) -> np.ndarray:
    mag, phase = stft_frames(noisy)
    bands = to_bands(mag, fb)
    logn = torch.from_numpy(np.log(bands + 1e-8).astype(np.float32)).unsqueeze(0)
    with torch.no_grad():
        gain, _vad = model.forward_seq(logn)
    gain = gain.squeeze(0).numpy()
    win = np.hanning(WIN_LENGTH)
    recs = []
    for t in range(len(mag)):
        g = upsample_gain(gain[t])
        if len(g) != mag.shape[1]:
            g = np.interp(np.linspace(0, 1, mag.shape[1]), np.linspace(0, 1, len(g)), g)
        spec = mag[t] * np.clip(g, 0.0, 1.0) * np.exp(1j * phase[t])
        recs.append(np.fft.irfft(spec, n=N_FFT).real[:WIN_LENGTH] * win)
    return overlap_add(recs, len(noisy)).astype(np.float64)


def evaluate(n_val: int | None = None) -> dict:
    if not WEIGHTS.exists() or not MANIFEST.exists():
        raise SystemExit("Train first (python mix_dataset.py && python train.py)")
    fb = filterbank()
    model = TinyMaskNet()
    model.load_state_dict(torch.load(WEIGHTS, map_location="cpu"))
    model.eval()
    rows = json.loads(MANIFEST.read_text())["rows"]
    mix_rows = [r for r in rows if not r.get("noise_only")]
    if n_val is None:
        n_val = max(4, len(mix_rows) // 8)
    hold = mix_rows[-n_val:]
    snr_in, snr_out, si_in, si_out = [], [], [], []
    stoi_in, stoi_out, pesq_in, pesq_out = [], [], [], []
    for row in hold:
        noisy = read_wav(MIXED_DIR / f"{row['id']}_noisy.wav")
        clean = read_wav(MIXED_DIR / f"{row['id']}_clean.wav")
        n = min(len(noisy), len(clean))
        noisy, clean = noisy[:n], clean[:n]
        if float(np.mean(clean ** 2)) < 1e-8:
            continue
        enh = enhance_wav(model, fb, noisy)
        snr_in.append(snr_db(clean, noisy))
        snr_out.append(snr_db(clean, enh))
        si_in.append(si_snr_db(clean, noisy))
        si_out.append(si_snr_db(clean, enh))
        a, b = try_stoi(clean, noisy), try_stoi(clean, enh)
        if a["available"] and b["available"]:
            stoi_in.append(a["value"])
            stoi_out.append(b["value"])
        c, d = try_pesq(clean, noisy), try_pesq(clean, enh)
        if c["available"] and d["available"]:
            pesq_in.append(c["value"])
            pesq_out.append(d["value"])
    out = {
        "clips": len(snr_out),
        "snr_in_db": round(float(np.mean(snr_in)), 3) if snr_in else None,
        "snr_out_db": round(float(np.mean(snr_out)), 3) if snr_out else None,
        "snr_improvement_db": round(float(np.mean(snr_out) - np.mean(snr_in)), 3) if snr_out else None,
        "si_snr_in_db": round(float(np.mean(si_in)), 3) if si_in else None,
        "si_snr_out_db": round(float(np.mean(si_out)), 3) if si_out else None,
        "stoi_in": round(float(np.mean(stoi_in)), 3) if stoi_in else None,
        "stoi_out": round(float(np.mean(stoi_out)), 3) if stoi_out else None,
        "pesq_in": round(float(np.mean(pesq_in)), 3) if pesq_in else None,
        "pesq_out": round(float(np.mean(pesq_out)), 3) if pesq_out else None,
        "stoi_status": "REAL / MEASURED" if stoi_out else "UNAVAILABLE (pip install pystoi)",
        "pesq_status": "REAL / MEASURED" if pesq_out else "UNAVAILABLE / TARGET only (pip install pesq)",
        "note": "Held-out REAL-mic additive mixes. Not DRDO field scores. SIH 15 dB / 0.85 / 2.5 remain TARGET.",
    }
    return out


if __name__ == "__main__":
    ev = evaluate()
    print(json.dumps(ev, indent=2))
    if META_JSON.exists():
        meta = json.loads(META_JSON.read_text())
        meta["eval"] = ev
        META_JSON.write_text(json.dumps(meta, indent=2))
        print("updated", META_JSON)
