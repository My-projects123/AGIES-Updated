#!/usr/bin/env python3
"""Raspberry Pi / laptop live two-mic cleaner (no website required).

    python live_two_mic.py
    python live_two_mic.py --seconds 8

Reads 2 channels from the USB interface, runs TinyML on the SPEECH channel,
plays the cleaned speech to the default output (headphones), and writes
recordings/live_speech_clean.wav plus recordings/live_reference.wav.

Does not implement LMS, DCCRN, Bluetooth, or wireless.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from audio_io import write_wav  # noqa: E402
from config import RECORDINGS_DIR, SAMPLE_RATE, ensure_data_dirs  # noqa: E402
from live_processor import TwoMicProcessor  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description="Two-mic TinyML live test")
    parser.add_argument("--seconds", type=float, default=6.0)
    args = parser.parse_args()
    ensure_data_dirs()
    try:
        from capture import record_stereo_seconds
    except Exception as exc:  # noqa: BLE001
        print("Cannot capture audio:", exc)
        return 1
    print(f"Recording {args.seconds:.1f}s of two-channel audio…")
    try:
        clip = record_stereo_seconds(args.seconds)
    except Exception as exc:  # noqa: BLE001
        print("FAILED:", exc)
        return 2
    proc = TwoMicProcessor()
    result = proc.process_full_stereo(clip["speech"], clip["reference"])
    write_wav(RECORDINGS_DIR / "live_speech_raw.wav", result["speech_raw"])
    write_wav(RECORDINGS_DIR / "live_reference.wav", result["reference_raw"])
    write_wav(RECORDINGS_DIR / "live_speech_clean.wav", result["speech_clean"])
    print("TinyML loaded:" , result["ml"])
    print("sample_rate:", SAMPLE_RATE, "channels: 2")
    print("latency_ms (last hop):", result["latency_ms"])
    print("gate_open:", result["gate_open"], "tiny_vad:", result["tiny_vad"])
    print("wrote recordings/live_speech_clean.wav")
    print("TinyML cleaned the SPEECH channel only. Reference is saved untouched.")
    if not result["ml"]:
        print("NOTE: no ONNX model found — Wiener + gate only. Train first: python train.py")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
