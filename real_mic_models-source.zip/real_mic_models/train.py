"""Train TinyMaskNet on REAL-mic mixed pairs, export ONNX + INT8.

    python mix_dataset.py
    python train.py
"""

from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import torch
from torch import nn

from audio_io import read_wav
from config import HIDDEN, HOP, MIXED_DIR, N_BANDS, N_FFT, SAMPLE_RATE, WIN_LENGTH
from fbanks import filterbank, to_bands
from model import TinyMaskNet
from paths import FP32_ONNX, INT8_ONNX, MANIFEST, META_JSON, MODELS, WEIGHTS

EPOCHS = 40
BATCH = 8
LR = 2e-3
VAD_WEIGHT = 0.5
COMPRESS = 0.3


def stft_mag(x: np.ndarray) -> np.ndarray:
    win = np.hanning(WIN_LENGTH)
    if len(x) < WIN_LENGTH:
        x = np.pad(x, (0, WIN_LENGTH - len(x)))
    hops = []
    for start in range(0, len(x) - WIN_LENGTH + 1, HOP):
        spec = np.fft.rfft(x[start : start + WIN_LENGTH] * win, n=N_FFT)
        hops.append(np.abs(spec) + 1e-12)
    return np.stack(hops, axis=0)


def frame_vad(mask: np.ndarray, clean_bands: np.ndarray, n_frames: int) -> np.ndarray:
    occ = np.zeros(n_frames)
    for f in range(n_frames):
        seg = mask[f * HOP : f * HOP + WIN_LENGTH]
        occ[f] = float(np.mean(seg)) if len(seg) else 0.0
    energy = clean_bands.sum(axis=1)
    thr = 0.02 * (float(np.max(energy)) + 1e-12)
    return ((occ > 0.35) & (energy > thr)).astype(np.float32)


def load_pairs(fb: np.ndarray) -> list[tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]]:
    if not MANIFEST.exists():
        raise SystemExit("No dataset yet. Record speech+noise, then: python mix_dataset.py")
    meta = json.loads(MANIFEST.read_text())
    out = []
    for row in meta["rows"]:
        stem = row["id"]
        noisy = read_wav(MIXED_DIR / f"{stem}_noisy.wav")
        clean = read_wav(MIXED_DIR / f"{stem}_clean.wav")
        mask = np.load(MIXED_DIR / f"{stem}_mask.npy")
        nm = stft_mag(noisy)
        cm = stft_mag(clean)
        t = min(len(nm), len(cm))
        nb = to_bands(nm[:t], fb)
        cb = to_bands(cm[:t], fb)
        irm = np.clip(cb / (nb + 1e-8), 0.0, 1.0)
        vad = frame_vad(mask, cb, t)
        logn = np.log(nb + 1e-8)
        out.append(
            (
                torch.from_numpy(logn.astype(np.float32)),
                torch.from_numpy(irm.astype(np.float32)),
                torch.from_numpy(nb.astype(np.float32)),
                torch.from_numpy(np.stack([vad], axis=-1)),
            )
        )
    return out


def export_onnx(seq_model: TinyMaskNet) -> None:
    stream = TinyMaskNet(N_BANDS, HIDDEN)
    stream.load_state_dict(seq_model.state_dict())
    stream.eval()
    bands = torch.zeros(1, 1, N_BANDS)
    h = torch.zeros(1, 1, HIDDEN)
    MODELS.mkdir(parents=True, exist_ok=True)
    names = dict(input_names=["bands", "h"], output_names=["gain", "vad", "h_out"], opset_version=14)
    try:
        torch.onnx.export(stream, (bands, h), str(FP32_ONNX), dynamo=False, **names)
    except TypeError:
        torch.onnx.export(stream, (bands, h), str(FP32_ONNX), **names)


def quantize() -> bool:
    try:
        from onnxruntime.quantization import QuantType, quantize_dynamic

        quantize_dynamic(str(FP32_ONNX), str(INT8_ONNX), weight_type=QuantType.QInt8)
        return True
    except Exception as exc:  # noqa: BLE001
        print("INT8 quantize skipped:", exc)
        return False


def main() -> None:
    fb = filterbank()
    data = load_pairs(fb)
    if len(data) < 8:
        raise SystemExit(f"Only {len(data)} clips. Record more speech/noise and re-run mix_dataset.py")
    n_val = max(4, len(data) // 8)
    train, val = data[:-n_val], data[-n_val:]
    model = TinyMaskNet()
    opt = torch.optim.Adam(model.parameters(), lr=LR)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
    bce = nn.BCELoss()
    print(f"params={model.param_count()} train={len(train)} val={len(val)} REAL-mic mixes")

    def batch_loss(batch):
        tmax = max(x.shape[0] for x, _, _, _ in batch)
        xb = torch.zeros(len(batch), tmax, N_BANDS)
        mb = torch.zeros(len(batch), tmax, N_BANDS)
        nbb = torch.zeros(len(batch), tmax, N_BANDS)
        vb = torch.zeros(len(batch), tmax, 1)
        wb = torch.zeros(len(batch), tmax, 1)
        for bi, (x, m, nbands, v) in enumerate(batch):
            tt = x.shape[0]
            xb[bi, :tt] = x
            mb[bi, :tt] = m
            nbb[bi, :tt] = nbands
            vb[bi, :tt] = v
            wb[bi, :tt] = 1.0
        gain, vad = model.forward_seq(xb)
        est = (gain * nbb).clamp(min=0.0) ** COMPRESS
        tgt = (mb * nbb).clamp(min=0.0) ** COMPRESS
        mask_loss = (((est - tgt) ** 2) * wb).sum() / wb.sum().clamp(min=1.0) / N_BANDS
        vad_loss = bce((vad * wb).clamp(1e-6, 1 - 1e-6), vb * wb)
        return mask_loss + VAD_WEIGHT * vad_loss, mask_loss, vad_loss

    t0 = time.perf_counter()
    for ep in range(EPOCHS):
        model.train()
        order = np.random.default_rng(ep).permutation(len(train))
        run = nbat = 0.0
        n = 0
        for s in range(0, len(train), BATCH):
            batch = [train[int(j)] for j in order[s : s + BATCH]]
            loss, ml, vl = batch_loss(batch)
            opt.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
            opt.step()
            run += float(loss.detach())
            nbat += 1
            n += 1
        sched.step()
        if (ep + 1) % 5 == 0 or ep == EPOCHS - 1:
            model.eval()
            with torch.no_grad():
                vloss, _, _ = batch_loss(val)
                gain, vad = model.forward_seq(torch.stack([v[0] for v in val]))
                tgt = torch.stack([v[3] for v in val])
                acc = float((((vad > 0.5).float() == tgt).float()).mean())
            print(f"epoch {ep + 1:>2}/{EPOCHS}  train {run / n:.4f}  val {float(vloss):.4f}  vad acc {acc:.3f}")
    train_s = time.perf_counter() - t0

    model.eval()
    with torch.no_grad():
        gain, vad = model.forward_seq(torch.stack([v[0] for v in val]))
        tgt = torch.stack([v[3] for v in val])
        vad_acc = float((((vad > 0.5).float() == tgt).float()).mean())

    MODELS.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), WEIGHTS)
    export_onnx(model)
    q = quantize()
    size = (INT8_ONNX if q and INT8_ONNX.exists() else FP32_ONNX).stat().st_size
    meta = {
        "params": model.param_count(),
        "epochs": EPOCHS,
        "train_clips": len(train),
        "val_clips": len(val),
        "train_seconds": round(train_s, 2),
        "size_kb": round(size / 1024.0, 2),
        "quantized": q,
        "heads": ["gain (32-band mask)", "vad (speech present)"],
        "vad_accuracy": round(vad_acc, 3),
        "train_data": "REAL microphone speech + REAL microphone noise, additive SNR mixes",
        "sample_rate": SAMPLE_RATE,
        "win": WIN_LENGTH,
        "hop": HOP,
        "n_bands": N_BANDS,
        "hidden": HIDDEN,
    }
    META_JSON.write_text(json.dumps(meta, indent=2))
    print("VAD acc", vad_acc)
    print("wrote", FP32_ONNX, INT8_ONNX if q else "(no int8)")


if __name__ == "__main__":
    main()
