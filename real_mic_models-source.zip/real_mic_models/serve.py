"""Launch the real-mic recorder + trainer + live cleaner.

    python serve.py
    open http://127.0.0.1:8090
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def main() -> None:
    import uvicorn

    host = os.environ.get("HOST", "0.0.0.0")
    port = int(os.environ.get("PORT", "8090"))
    print(f"Real-mic TinyML → http://127.0.0.1:{port}")
    print("Record YOUR voice and YOUR room noise, train, then live-clean.")
    uvicorn.run("api:app", host=host, port=port, reload=False, log_level="info")


if __name__ == "__main__":
    main()
